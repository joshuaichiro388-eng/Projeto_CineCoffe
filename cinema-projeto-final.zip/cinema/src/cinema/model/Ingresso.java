package cinema.model;

import cinema.enums.StatusIngresso;

import java.time.LocalDateTime;

public abstract class Ingresso {

    private static int proximoId = 1;

    protected int id;
    protected Sessao sessao;
    protected Cliente cliente;
    protected Funcionario funcionario;
    protected StatusIngresso status;
    protected LocalDateTime dataCompra;
    protected LocalDateTime dataVenda;
    protected double precoFinal;

    public Ingresso(Sessao sessao, Cliente cliente) {
        this.id = proximoId++;
        this.sessao = sessao;
        this.cliente = cliente;
        this.status = StatusIngresso.reservado;
        this.dataCompra = LocalDateTime.now();
    }

    public abstract double calcularPreco(double precoBase);

    public abstract String getDescricaoTipo();

    public void confirmarVenda(Funcionario funcionario) {
        this.funcionario = funcionario;
        this.status = StatusIngresso.pago;
        this.dataVenda = LocalDateTime.now();
    }

    public int getId() {
        return id;
    }

    public Sessao getSessao() {
        return sessao;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public StatusIngresso getStatus() {
        return status;
    }

    public LocalDateTime getDataCompra() {
        return dataCompra;
    }

    public LocalDateTime getDataVenda() {
        return dataVenda;
    }

    public double getPrecoFinal() {
        return precoFinal;
    }

    public void setPrecoFinal(double precoFinal) {
        this.precoFinal = precoFinal;
    }

    @Override
    public String toString() {
        return "Ingresso #" + id + " - " + cliente.getNome() + " - " + sessao + " [" + status + "]";
    }
}
