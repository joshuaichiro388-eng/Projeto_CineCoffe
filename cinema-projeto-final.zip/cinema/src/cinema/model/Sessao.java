package cinema.model;

import cinema.enums.StatusSessao;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Sessao {

    private static final DateTimeFormatter formatoHorario = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private int id;
    private Filme filme;
    private Sala sala;
    private LocalDateTime horario;
    private StatusSessao status;
    private int vagasDisponiveis;

    public Sessao(int id, Filme filme, Sala sala, LocalDateTime horario) {
        this.id = id;
        this.filme = filme;
        this.sala = sala;
        this.horario = horario;
        this.status = StatusSessao.agendada;
        this.vagasDisponiveis = sala.getCapacidade();
    }

    public int getId() {
        return id;
    }

    public Filme getFilme() {
        return filme;
    }

    public Sala getSala() {
        return sala;
    }

    public LocalDateTime getHorario() {
        return horario;
    }

    public StatusSessao getStatus() {
        return status;
    }

    public void setStatus(StatusSessao status) {
        this.status = status;
    }

    public int getVagasDisponiveis() {
        return vagasDisponiveis;
    }

    public boolean possuiIngressos() {
        return vagasDisponiveis < sala.getCapacidade();
    }

    public void atualizarDados(Filme novoFilme, Sala novaSala, LocalDateTime novoHorario, StatusSessao novoStatus) {
        boolean mudouFilme = filme.getId() != novoFilme.getId();
        boolean mudouSala = sala.getId() != novaSala.getId();
        if ((mudouFilme || mudouSala) && possuiIngressos()) {
            throw new IllegalStateException("Esta sessão já possui ingressos comprados. Só é possível alterar o horário e o status.");
        }
        if (mudouSala) {
            this.vagasDisponiveis = novaSala.getCapacidade();
        }
        this.filme = novoFilme;
        this.sala = novaSala;
        this.horario = novoHorario;
        this.status = novoStatus;
    }

    public void ocuparVaga() {
        ocuparVaga(1);
    }

    public void ocuparVaga(int quantidade) {
        if (quantidade > 0 && vagasDisponiveis >= quantidade) {
            vagasDisponiveis -= quantidade;
        }
    }

    @Override
    public String toString() {
        return filme.getTitulo() + " - " + sala + " - " + horario.format(formatoHorario);
    }
}
