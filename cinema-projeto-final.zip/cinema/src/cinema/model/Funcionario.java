package cinema.model;

import cinema.enums.Cargo;

import java.time.LocalDate;

public class Funcionario extends Pessoa {

    private Cargo cargo;
    private double salario;

    public Funcionario(String nome, String cpf, LocalDate dataNascimento, String telefone,
                        Cargo cargo, double salario) {
        super(nome, cpf, dataNascimento, telefone);
        this.cargo = cargo;
        this.salario = salario;
    }

    public Cargo getCargo() {
        return cargo;
    }

    public double getSalario() {
        return salario;
    }

    public void atualizarDados(Funcionario outro) {
        this.nome = outro.nome;
        this.dataNascimento = outro.dataNascimento;
        this.telefone = outro.telefone;
        this.cargo = outro.cargo;
        this.salario = outro.salario;
    }

    @Override
    public String getDescricaoPapel() {
        return "Funcionário - " + cargo;
    }

    @Override
    public String toString() {
        return super.toString() + " [" + cargo + "]";
    }
}
