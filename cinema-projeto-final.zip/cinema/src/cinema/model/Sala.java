package cinema.model;

import cinema.enums.TipoSala;

public class Sala {

    private int id;
    private int numero;
    private int capacidade;
    private TipoSala tipoSala;

    public Sala(int id, int numero, int capacidade, TipoSala tipoSala) {
        this.id = id;
        this.numero = numero;
        this.capacidade = capacidade;
        this.tipoSala = tipoSala;
    }

    public int getId() {
        return id;
    }

    public int getNumero() {
        return numero;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public TipoSala getTipoSala() {
        return tipoSala;
    }

    public void atualizarDados(Sala outra) {
        this.numero = outra.numero;
        this.capacidade = outra.capacidade;
        this.tipoSala = outra.tipoSala;
    }

    @Override
    public String toString() {
        return "Sala " + numero + " (" + tipoSala + ", " + capacidade + " lugares)";
    }
}
