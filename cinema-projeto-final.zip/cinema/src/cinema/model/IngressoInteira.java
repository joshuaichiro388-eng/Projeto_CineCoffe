package cinema.model;

public class IngressoInteira extends Ingresso {

    public IngressoInteira(Sessao sessao, Cliente cliente) {
        super(sessao, cliente);
    }

    @Override
    public double calcularPreco(double precoBase) {
        return precoBase;
    }

    @Override
    public String getDescricaoTipo() {
        return "Inteira";
    }
}
