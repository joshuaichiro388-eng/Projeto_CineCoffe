package cinema.model;

public class IngressoMeia extends Ingresso {

    private static final double desconto = 0.5;

    public IngressoMeia(Sessao sessao, Cliente cliente) {
        super(sessao, cliente);
    }

    @Override
    public double calcularPreco(double precoBase) {
        return precoBase * desconto;
    }

    @Override
    public String getDescricaoTipo() {
        return "Meia";
    }
}
