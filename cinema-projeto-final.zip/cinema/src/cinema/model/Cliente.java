package cinema.model;

import java.time.LocalDate;

public class Cliente extends Pessoa {

    private String email;

    public Cliente(String nome, String cpf, LocalDate dataNascimento, String telefone, String email) {
        super(nome, cpf, dataNascimento, telefone);
        this.email = email;
    }

    public Cliente(String nome, String cpf, LocalDate dataNascimento) {
        this(nome, cpf, dataNascimento, "", "");
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void atualizarDados(Cliente outro) {
        this.nome = outro.nome;
        this.dataNascimento = outro.dataNascimento;
        this.telefone = outro.telefone;
        this.email = outro.email;
    }

    @Override
    public String getDescricaoPapel() {
        return "Cliente";
    }
}
