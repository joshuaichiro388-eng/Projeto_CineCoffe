package cinema.model;

import java.time.LocalDate;
import java.time.Period;

public abstract class Pessoa {

    protected String nome;
    protected String cpf;
    protected LocalDate dataNascimento;
    protected String telefone;

    public Pessoa(String nome, String cpf, LocalDate dataNascimento, String telefone) {
        this.nome = nome;
        this.cpf = cpf;
        this.dataNascimento = dataNascimento;
        this.telefone = telefone;
    }

    public int getIdade() {
        return Period.between(dataNascimento, LocalDate.now()).getYears();
    }

    public String getNome() {
        return nome;
    }

    public String getCpf() {
        return cpf;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public abstract String getDescricaoPapel();

    @Override
    public String toString() {
        return nome + " (CPF: " + cpf + ")";
    }
}
