package cinema.model;

import cinema.enums.Classificacao;
import cinema.enums.Genero;

public class Filme {

    private int id;
    private String titulo;
    private Genero genero;
    private Classificacao classificacao;
    private int duracaoMinutos;
    private double nota;

    public Filme(int id, String titulo, Genero genero, Classificacao classificacao,
                 int duracaoMinutos, double nota) {
        this.id = id;
        this.titulo = titulo;
        this.genero = genero;
        this.classificacao = classificacao;
        this.duracaoMinutos = duracaoMinutos;
        this.nota = nota;
    }

    public Filme(int id, String titulo, Genero genero, Classificacao classificacao, int duracaoMinutos) {
        this(id, titulo, genero, classificacao, duracaoMinutos, 0.0);
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public Genero getGenero() {
        return genero;
    }

    public Classificacao getClassificacao() {
        return classificacao;
    }

    public int getDuracaoMinutos() {
        return duracaoMinutos;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public void atualizarDados(Filme outro) {
        this.titulo = outro.titulo;
        this.genero = outro.genero;
        this.classificacao = outro.classificacao;
        this.duracaoMinutos = outro.duracaoMinutos;
        this.nota = outro.nota;
    }

    @Override
    public String toString() {
        return titulo + " (" + genero + " - " + classificacao + ")";
    }
}
