package cinema.repository;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;

public class RepositorioEmMemoria<T, ID> implements Repositorio<T, ID> {

    private final Map<ID, T> dados = new LinkedHashMap<>();
    private final Function<T, ID> extratorId;

    public RepositorioEmMemoria(Function<T, ID> extratorId) {
        this.extratorId = extratorId;
    }

    @Override
    public void salvar(T entidade) {
        dados.put(extratorId.apply(entidade), entidade);
    }

    @Override
    public void atualizar(T entidade) {
        dados.put(extratorId.apply(entidade), entidade);
    }

    @Override
    public void remover(ID id) {
        dados.remove(id);
    }

    @Override
    public Optional<T> buscarPorId(ID id) {
        return Optional.ofNullable(dados.get(id));
    }

    @Override
    public List<T> listarTodos() {
        return new ArrayList<>(dados.values());
    }
}
