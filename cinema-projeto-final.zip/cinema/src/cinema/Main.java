package cinema;

import cinema.view.Estilo;
import cinema.view.TelaAbertura;
import cinema.view.TelaPrincipal;

import javax.swing.SwingUtilities;

public class Main {

    public static void main(String[] args) {
        Estilo.aplicarTema();
        AplicacaoContexto contexto = new AplicacaoContexto();
        SwingUtilities.invokeLater(() -> {
            TelaAbertura abertura = new TelaAbertura(() -> new TelaPrincipal(contexto).setVisible(true));
            abertura.exibir();
        });
    }
}
