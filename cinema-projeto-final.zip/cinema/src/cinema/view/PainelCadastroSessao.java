package cinema.view;

import cinema.enums.StatusSessao;
import cinema.model.Filme;
import cinema.model.Sala;
import cinema.model.Sessao;
import cinema.repository.Repositorio;
import cinema.service.ConsultaIngressoService;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class PainelCadastroSessao extends JPanel {

    private static final DateTimeFormatter formatoHorario = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final Repositorio<Sessao, Integer> sessaoRepositorio;
    private final Repositorio<Filme, Integer> filmeRepositorio;
    private final Repositorio<Sala, Integer> salaRepositorio;
    private final ConsultaIngressoService consultaIngressoService;

    private final JComboBox<Filme> comboFilme = new JComboBox<>();
    private final JComboBox<Sala> comboSala = new JComboBox<>();
    private final JTextField campoHorario = new JTextField(16);
    private final JComboBox<StatusSessao> comboStatus = new JComboBox<>(StatusSessao.values());

    private final DefaultTableModel modeloTabela = new DefaultTableModel(
            new Object[]{"Id", "Filme", "Sala", "Horário", "Status", "Vagas"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable tabelaSessoes = new JTable(modeloTabela);

    private static int proximoId = 1;
    private Integer idSelecionado = null;
    private Integer idEmEdicao = null;

    public PainelCadastroSessao(Repositorio<Sessao, Integer> sessaoRepositorio,
                                 Repositorio<Filme, Integer> filmeRepositorio,
                                 Repositorio<Sala, Integer> salaRepositorio,
                                 ConsultaIngressoService consultaIngressoService) {
        this.consultaIngressoService = consultaIngressoService;
        this.sessaoRepositorio = sessaoRepositorio;
        this.filmeRepositorio = filmeRepositorio;
        this.salaRepositorio = salaRepositorio;
        setLayout(new BorderLayout(10, 10));
        setBorder(Estilo.margemPainel());
        add(Estilo.cabecalho("Cadastro de Sessões", "Defina o filme, a sala e o horário de cada sessão", criarPainelFormulario()), BorderLayout.NORTH);
        add(Estilo.rolagem(tabelaSessoes), BorderLayout.CENTER);
        add(criarPainelBotoes(), BorderLayout.SOUTH);
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                atualizarCombosFilmeSala();
            }
        });
        atualizarCombosFilmeSala();
        atualizarTabela();
    }

    private JPanel criarPainelFormulario() {
        return Estilo.formulario(new String[]{"Filme", "Sala", "Horário (dd/MM/yyyy HH:mm)", "Status"},
                comboFilme, comboSala, campoHorario, comboStatus);
    }

    private JPanel criarPainelBotoes() {
        JPanel painel = Estilo.barraBotoes();

        JButton botaoCadastrar = Estilo.botao("Cadastrar", Estilo.Tipo.primario);
        JButton botaoAlterar = Estilo.botao("Alterar", Estilo.Tipo.secundario);
        JButton botaoRemover = Estilo.botao("Remover", Estilo.Tipo.perigo);
        JButton botaoLimpar = Estilo.botao("Limpar", Estilo.Tipo.neutro);

        botaoCadastrar.addActionListener(e -> cadastrar());
        botaoAlterar.addActionListener(e -> alterar());
        botaoRemover.addActionListener(e -> remover());
        botaoLimpar.addActionListener(e -> limparFormulario());

        tabelaSessoes.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                registrarSelecao();
            }
        });

        painel.add(botaoCadastrar);
        painel.add(botaoAlterar);
        painel.add(botaoRemover);
        painel.add(botaoLimpar);
        return painel;
    }

    private void cadastrar() {
        if (comboFilme.getSelectedItem() == null || comboSala.getSelectedItem() == null) {
            JOptionPane.showMessageDialog(this, "Cadastre ao menos um filme e uma sala antes de criar uma sessão.");
            return;
        }
        LocalDateTime horario = lerHorario();
        if (horario == null) {
            return;
        }
        Filme filme = (Filme) comboFilme.getSelectedItem();
        Sala sala = (Sala) comboSala.getSelectedItem();
        StatusSessao status = (StatusSessao) comboStatus.getSelectedItem();

        if (idEmEdicao != null) {
            Sessao existente = sessaoRepositorio.buscarPorId(idEmEdicao).orElse(null);
            if (existente != null) {
                try {
                    existente.atualizarDados(filme, sala, horario, status);
                } catch (IllegalStateException ex) {
                    JOptionPane.showMessageDialog(this, ex.getMessage());
                    return;
                }
            }
        } else {
            Sessao sessao = new Sessao(proximoId, filme, sala, horario);
            sessao.setStatus(status);
            sessaoRepositorio.salvar(sessao);
            proximoId++;
        }
        atualizarTabela();
        limparFormulario();
    }

    private void alterar() {
        if (idSelecionado == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma sessão na tabela para alterar.");
            return;
        }
        sessaoRepositorio.buscarPorId(idSelecionado).ifPresent(sessao -> {
            idEmEdicao = sessao.getId();
            comboFilme.setSelectedItem(sessao.getFilme());
            comboSala.setSelectedItem(sessao.getSala());
            campoHorario.setText(sessao.getHorario().format(formatoHorario));
            comboStatus.setSelectedItem(sessao.getStatus());
        });
    }

    private void remover() {
        if (idSelecionado == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma sessão na tabela para remover.");
            return;
        }
        Sessao sessao = sessaoRepositorio.buscarPorId(idSelecionado).orElse(null);
        if (sessao != null && consultaIngressoService.sessaoPossuiIngressos(sessao)) {
            JOptionPane.showMessageDialog(this, "Esta sessão possui ingressos e não pode ser removida.");
            return;
        }
        sessaoRepositorio.remover(idSelecionado);
        atualizarTabela();
        limparFormulario();
    }


    private LocalDateTime lerHorario() {
        try {
            return LocalDateTime.parse(campoHorario.getText().trim(), formatoHorario);
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Horário inválido. Use o formato dd/MM/yyyy HH:mm.");
            return null;
        }
    }

    private void registrarSelecao() {
        int linha = tabelaSessoes.getSelectedRow();
        if (linha < 0) {
            return;
        }
        idSelecionado = (int) modeloTabela.getValueAt(linha, 0);
    }

    private void limparFormulario() {
        campoHorario.setText("");
        comboStatus.setSelectedIndex(0);
        idSelecionado = null;
        idEmEdicao = null;
        tabelaSessoes.clearSelection();
    }

    private void atualizarCombosFilmeSala() {
        Filme filmeSelecionado = (Filme) comboFilme.getSelectedItem();
        Sala salaSelecionada = (Sala) comboSala.getSelectedItem();

        comboFilme.removeAllItems();
        for (Filme filme : filmeRepositorio.listarTodos()) {
            comboFilme.addItem(filme);
        }
        if (filmeSelecionado != null) {
            comboFilme.setSelectedItem(filmeSelecionado);
        }

        comboSala.removeAllItems();
        for (Sala sala : salaRepositorio.listarTodos()) {
            comboSala.addItem(sala);
        }
        if (salaSelecionada != null) {
            comboSala.setSelectedItem(salaSelecionada);
        }
    }

    private void atualizarTabela() {
        modeloTabela.setRowCount(0);
        List<Sessao> sessoes = sessaoRepositorio.listarTodos();
        for (Sessao sessao : sessoes) {
            modeloTabela.addRow(new Object[]{
                    sessao.getId(),
                    sessao.getFilme().getTitulo(),
                    sessao.getSala(),
                    sessao.getHorario().format(formatoHorario),
                    sessao.getStatus(),
                    sessao.getVagasDisponiveis()
            });
        }
    }
}
