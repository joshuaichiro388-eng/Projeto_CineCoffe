package cinema.view;

import cinema.model.Cliente;
import cinema.repository.Repositorio;
import cinema.service.ConsultaIngressoService;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class PainelCadastroCliente extends JPanel {

    private final ConsultaIngressoService consultaIngressoService;
    private static final DateTimeFormatter formatoData = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final Repositorio<Cliente, String> clienteRepositorio;

    private final JTextField campoNome = new JTextField(20);
    private final JTextField campoCpf = new JTextField(12);
    private final JTextField campoDataNascimento = new JTextField(10);
    private final JTextField campoTelefone = new JTextField(12);
    private final JTextField campoEmail = new JTextField(18);

    private final DefaultTableModel modeloTabela = new DefaultTableModel(
            new Object[]{"CPF", "Nome", "Nascimento", "Telefone", "Email"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable tabelaClientes = new JTable(modeloTabela);

    private String cpfSelecionado = null;
    private String cpfEmEdicao = null;

    public PainelCadastroCliente(Repositorio<Cliente, String> clienteRepositorio, ConsultaIngressoService consultaIngressoService) {
        this.clienteRepositorio = clienteRepositorio;
        this.consultaIngressoService = consultaIngressoService;
        setLayout(new BorderLayout(10, 10));
        setBorder(Estilo.margemPainel());
        add(Estilo.cabecalho("Cadastro de Clientes", "Mantenha os dados dos clientes do cinema", criarPainelFormulario()), BorderLayout.NORTH);
        add(Estilo.rolagem(tabelaClientes), BorderLayout.CENTER);
        add(criarPainelBotoes(), BorderLayout.SOUTH);
        atualizarTabela();
    }

    private JPanel criarPainelFormulario() {
        return Estilo.formulario(new String[]{"Nome", "CPF", "Nascimento", "Telefone", "Email"},
                campoNome, campoCpf, campoDataNascimento, campoTelefone, campoEmail);
    }

    private JPanel criarPainelBotoes() {
        JPanel painel = Estilo.barraBotoes();

        JButton botaoCadastrar = Estilo.botao("Cadastrar", Estilo.Tipo.primario);
        JButton botaoAlterar = Estilo.botao("Alterar", Estilo.Tipo.secundario);
        JButton botaoRemover = Estilo.botao("Remover", Estilo.Tipo.perigo);
        JButton botaoLimpar = Estilo.botao("Limpar", Estilo.Tipo.neutro);

        botaoCadastrar.addActionListener(e -> cadastrar());
        botaoAlterar.addActionListener(e -> alterar());
        botaoRemover.addActionListener(e -> remover());
        botaoLimpar.addActionListener(e -> limparFormulario());

        tabelaClientes.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                registrarSelecao();
            }
        });

        painel.add(botaoCadastrar);
        painel.add(botaoAlterar);
        painel.add(botaoRemover);
        painel.add(botaoLimpar);
        return painel;
    }

    private void cadastrar() {
        Cliente cliente = lerFormulario();
        if (cliente == null) {
            return;
        }
        if (cpfEmEdicao != null) {
            clienteRepositorio.buscarPorId(cpfEmEdicao).ifPresent(existente -> existente.atualizarDados(cliente));
        } else {
            if (clienteRepositorio.buscarPorId(cliente.getCpf()).isPresent()) {
                JOptionPane.showMessageDialog(this, "Já existe um cliente cadastrado com esse CPF.");
                return;
            }
            clienteRepositorio.salvar(cliente);
        }
        atualizarTabela();
        limparFormulario();
    }

    private void alterar() {
        if (cpfSelecionado == null) {
            JOptionPane.showMessageDialog(this, "Selecione um cliente na tabela para alterar.");
            return;
        }
        clienteRepositorio.buscarPorId(cpfSelecionado).ifPresent(cliente -> {
            cpfEmEdicao = cliente.getCpf();
            campoNome.setText(cliente.getNome());
            campoCpf.setText(cliente.getCpf());
            campoCpf.setEditable(false);
            campoDataNascimento.setText(cliente.getDataNascimento().format(formatoData));
            campoTelefone.setText(cliente.getTelefone());
            campoEmail.setText(cliente.getEmail());
        });
    }

    private void remover() {
        if (cpfSelecionado == null) {
            JOptionPane.showMessageDialog(this, "Selecione um cliente na tabela para remover.");
            return;
        }
        Cliente cliente = clienteRepositorio.buscarPorId(cpfSelecionado).orElse(null);
        if (cliente != null && consultaIngressoService.clientePossuiIngressos(cliente)) {
            JOptionPane.showMessageDialog(this, "Este cliente possui ingressos e não pode ser removido.");
            return;
        }
        clienteRepositorio.remover(cpfSelecionado);
        atualizarTabela();
        limparFormulario();
    }

    private Cliente lerFormulario() {
        String nome = campoNome.getText().trim();
        if (nome.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o nome do cliente.");
            return null;
        }

        String cpf = campoCpf.getText().trim();
        if (cpf.length() != 11 || !cpf.chars().allMatch(Character::isDigit)) {
            JOptionPane.showMessageDialog(this, "CPF inválido. Informe apenas os 11 dígitos.");
            return null;
        }

        LocalDate dataNascimento;
        try {
            dataNascimento = LocalDate.parse(campoDataNascimento.getText().trim(), formatoData);
            if (dataNascimento.isAfter(LocalDate.now())) {
                throw new DateTimeParseException("data futura", campoDataNascimento.getText(), 0);
            }
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Data de nascimento inválida. Use o formato dd/MM/yyyy.");
            return null;
        }

        String telefone = campoTelefone.getText().trim();
        String email = campoEmail.getText().trim();

        return new Cliente(nome, cpf, dataNascimento, telefone, email);
    }

    private void registrarSelecao() {
        int linha = tabelaClientes.getSelectedRow();
        if (linha < 0) {
            return;
        }
        cpfSelecionado = (String) modeloTabela.getValueAt(linha, 0);
    }

    private void limparFormulario() {
        campoNome.setText("");
        campoCpf.setText("");
        campoDataNascimento.setText("");
        campoTelefone.setText("");
        campoEmail.setText("");
        cpfSelecionado = null;
        cpfEmEdicao = null;
        campoCpf.setEditable(true);
        tabelaClientes.clearSelection();
    }

    private void atualizarTabela() {
        modeloTabela.setRowCount(0);
        List<Cliente> clientes = clienteRepositorio.listarTodos();
        for (Cliente cliente : clientes) {
            modeloTabela.addRow(new Object[]{
                    cliente.getCpf(),
                    cliente.getNome(),
                    cliente.getDataNascimento().format(formatoData),
                    cliente.getTelefone(),
                    cliente.getEmail()
            });
        }
    }
}
