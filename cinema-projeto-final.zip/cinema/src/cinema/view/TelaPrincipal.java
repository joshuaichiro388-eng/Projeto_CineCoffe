package cinema.view;

import cinema.AplicacaoContexto;
import cinema.enums.StatusIngresso;
import cinema.model.Ingresso;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.RenderingHints;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;

public class TelaPrincipal extends JFrame {

    private static final int larguraMenu = 240;

    private final AplicacaoContexto contexto;
    private final CardLayout cardLayout = new CardLayout();
    private final JPanel painelConteudo = new JPanel(cardLayout);
    private final JLabel tituloSecao = new JLabel();
    private final Map<String, BotaoMenu> botoesMenu = new LinkedHashMap<>();
    private final List<Runnable> atualizadoresInicio = new ArrayList<>();

    public TelaPrincipal(AplicacaoContexto contexto) {
        super("CineCoffe");
        this.contexto = contexto;
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1180, 760);
        setMinimumSize(new Dimension(1000, 680));
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        montarPaineis();
        add(criarMenuLateral(), BorderLayout.WEST);
        add(criarAreaPrincipal(), BorderLayout.CENTER);
        navegar("inicio", "Início");
    }

    private JPanel criarMenuLateral() {
        JPanel menu = new JPanel();
        menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));
        menu.setBackground(Estilo.escuro);
        menu.setPreferredSize(new Dimension(larguraMenu, 0));
        menu.setBorder(BorderFactory.createEmptyBorder(24, 12, 20, 12));

        JLabel logo = new JLabel("CineCoffe");
        logo.setFont(Estilo.fonte(Font.BOLD, 24));
        logo.setForeground(Color.WHITE);
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);
        logo.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));

        JLabel subtitulo = new JLabel("Sistema de cinema");
        subtitulo.setFont(Estilo.fonte(Font.PLAIN, 12));
        subtitulo.setForeground(new Color(0x9AA0B5));
        subtitulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        subtitulo.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));

        menu.add(logo);
        menu.add(subtitulo);
        menu.add(Box.createVerticalStrut(26));

        adicionarItem(menu, "Início", "inicio", "Início");

        adicionarGrupo(menu, "CADASTROS");
        adicionarItem(menu, "Filmes", "cadastroFilme", "Cadastros  ›  Filmes");
        adicionarItem(menu, "Salas", "cadastroSala", "Cadastros  ›  Salas");
        adicionarItem(menu, "Sessões", "cadastroSessao", "Cadastros  ›  Sessões");
        adicionarItem(menu, "Clientes", "cadastroCliente", "Cadastros  ›  Clientes");
        adicionarItem(menu, "Funcionários", "cadastroFuncionario", "Cadastros  ›  Funcionários");

        adicionarGrupo(menu, "CONSULTAS");
        adicionarItem(menu, "Sessões", "consultaSessao", "Consultas  ›  Sessões");
        adicionarItem(menu, "Ingressos", "consultaIngresso", "Consultas  ›  Ingressos");

        adicionarGrupo(menu, "MOVIMENTAÇÕES");
        adicionarItem(menu, "Comprar Ingresso", "compraIngresso", "Movimentações  ›  Comprar Ingresso");
        adicionarItem(menu, "Vender Ingresso", "vendaIngresso", "Movimentações  ›  Vender Ingresso");

        menu.add(Box.createVerticalGlue());
        return menu;
    }

    private void adicionarGrupo(JPanel menu, String nome) {
        menu.add(Box.createVerticalStrut(18));
        JLabel rotulo = new JLabel(nome);
        rotulo.setFont(Estilo.fonte(Font.BOLD, 11));
        rotulo.setForeground(new Color(0x7C839B));
        rotulo.setAlignmentX(Component.LEFT_ALIGNMENT);
        rotulo.setBorder(BorderFactory.createEmptyBorder(0, 10, 6, 0));
        menu.add(rotulo);
    }

    private void adicionarItem(JPanel menu, String rotulo, String nomeCard, String titulo) {
        BotaoMenu botao = new BotaoMenu(rotulo);
        botao.setAlignmentX(Component.LEFT_ALIGNMENT);
        botao.setPreferredSize(new Dimension(larguraMenu, 38));
        botao.setMinimumSize(new Dimension(0, 38));
        botao.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        botao.addActionListener(e -> navegar(nomeCard, titulo));
        botoesMenu.put(nomeCard, botao);
        menu.add(botao);
        menu.add(Box.createVerticalStrut(2));
    }

    private JPanel criarAreaPrincipal() {
        tituloSecao.setFont(Estilo.fonte(Font.BOLD, 15));
        tituloSecao.setForeground(Estilo.texto);

        JPanel topo = new JPanel(new BorderLayout());
        topo.setBackground(Color.WHITE);
        topo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, Estilo.borda),
                BorderFactory.createEmptyBorder(15, 24, 15, 24)));
        topo.add(tituloSecao, BorderLayout.WEST);

        painelConteudo.setBackground(Estilo.fundo);

        JPanel area = new JPanel(new BorderLayout());
        area.add(topo, BorderLayout.NORTH);
        area.add(painelConteudo, BorderLayout.CENTER);
        return area;
    }

    private void navegar(String nomeCard, String titulo) {
        cardLayout.show(painelConteudo, nomeCard);
        tituloSecao.setText(titulo);
        botoesMenu.forEach((nome, botao) -> botao.setAtivo(nome.equals(nomeCard)));
    }

    private void montarPaineis() {
        painelConteudo.add(criarPainelInicio(), "inicio");
        painelConteudo.add(new PainelCadastroFilme(contexto.getFilmeRepositorio(), contexto.getConsultaSessaoService()), "cadastroFilme");
        painelConteudo.add(new PainelCadastroSala(contexto.getSalaRepositorio(), contexto.getConsultaSessaoService()), "cadastroSala");
        painelConteudo.add(new PainelCadastroSessao(contexto.getSessaoRepositorio(),
                contexto.getFilmeRepositorio(), contexto.getSalaRepositorio(), contexto.getConsultaIngressoService()), "cadastroSessao");
        painelConteudo.add(new PainelCadastroCliente(contexto.getClienteRepositorio(), contexto.getConsultaIngressoService()), "cadastroCliente");
        painelConteudo.add(new PainelCadastroFuncionario(contexto.getFuncionarioRepositorio(), contexto.getConsultaIngressoService()), "cadastroFuncionario");
        painelConteudo.add(new PainelConsultaSessao(contexto.getConsultaSessaoService()), "consultaSessao");
        painelConteudo.add(new PainelConsultaIngresso(contexto.getConsultaIngressoService(),
                contexto.getClienteRepositorio()), "consultaIngresso");
        painelConteudo.add(new PainelCompraIngresso(contexto.getSessaoRepositorio(), contexto.getClienteRepositorio(),
                contexto.getIngressoRepositorio(), contexto.getVendaService()), "compraIngresso");
        painelConteudo.add(new PainelVendaIngresso(contexto.getIngressoRepositorio(),
                contexto.getFuncionarioRepositorio(), contexto.getVendaService()), "vendaIngresso");
    }

    private JPanel criarPainelInicio() {
        JLabel titulo = new JLabel("Bem-vindo ao CineCoffe");
        titulo.setFont(Estilo.fonte(Font.BOLD, 26));
        titulo.setForeground(Estilo.texto);

        JLabel subtitulo = new JLabel("Filmes em destaque e um resumo do cinema.");
        subtitulo.setFont(Estilo.fonte(Font.PLAIN, 14));
        subtitulo.setForeground(Estilo.textoSuave);

        JPanel textos = new JPanel(new BorderLayout(0, 2));
        textos.setOpaque(false);
        textos.add(titulo, BorderLayout.NORTH);
        textos.add(subtitulo, BorderLayout.CENTER);

        JPanel destaques = new JPanel(new GridLayout(1, 3, 16, 0));
        destaques.setOpaque(false);
        destaques.add(new ImagemCartao("filme1.png", "Filme 1"));
        destaques.add(new ImagemCartao("filme2.png", "Filme 2"));
        destaques.add(new ImagemCartao("filme3.png", "Filme 3"));

        JPanel resumo = new JPanel(new GridLayout(2, 4, 16, 16));
        resumo.setOpaque(false);
        resumo.setPreferredSize(new Dimension(0, 196));
        adicionarCartao(resumo, "Filmes", () -> String.valueOf(contexto.getFilmeRepositorio().listarTodos().size()));
        adicionarCartao(resumo, "Salas", () -> String.valueOf(contexto.getSalaRepositorio().listarTodos().size()));
        adicionarCartao(resumo, "Sessões", () -> String.valueOf(contexto.getSessaoRepositorio().listarTodos().size()));
        adicionarCartao(resumo, "Clientes", () -> String.valueOf(contexto.getClienteRepositorio().listarTodos().size()));
        adicionarCartao(resumo, "Funcionários", () -> String.valueOf(contexto.getFuncionarioRepositorio().listarTodos().size()));
        adicionarCartao(resumo, "Ingressos reservados", () -> String.valueOf(contarIngressos(StatusIngresso.reservado)));
        adicionarCartao(resumo, "Ingressos vendidos", () -> String.valueOf(contarIngressos(StatusIngresso.pago)));
        adicionarCartao(resumo, "Faturamento", () -> String.format("R$ %.2f", calcularFaturamento()));

        JPanel painel = new JPanel(new BorderLayout(0, 18));
        painel.setBackground(Estilo.fundo);
        painel.setBorder(Estilo.margemPainel());
        painel.add(textos, BorderLayout.NORTH);
        painel.add(destaques, BorderLayout.CENTER);
        painel.add(resumo, BorderLayout.SOUTH);

        painel.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                atualizadoresInicio.forEach(Runnable::run);
            }
        });
        atualizadoresInicio.forEach(Runnable::run);
        return painel;
    }

    private void adicionarCartao(JPanel grade, String nome, Supplier<String> valor) {
        CartaoResumo cartao = new CartaoResumo(nome);
        grade.add(cartao);
        atualizadoresInicio.add(() -> cartao.setValor(valor.get()));
    }

    private long contarIngressos(StatusIngresso status) {
        return contexto.getIngressoRepositorio().listarTodos().stream()
                .filter(i -> i.getStatus() == status)
                .count();
    }

    private double calcularFaturamento() {
        return contexto.getIngressoRepositorio().listarTodos().stream()
                .filter(i -> i.getStatus() == StatusIngresso.pago)
                .mapToDouble(Ingresso::getPrecoFinal)
                .sum();
    }

    public JPanel getPainelConteudo() {
        return painelConteudo;
    }

    private static class BotaoMenu extends JButton {

        private boolean ativo = false;
        private boolean sobre = false;

        BotaoMenu(String rotulo) {
            super(rotulo);
            setHorizontalAlignment(LEFT);
            setForeground(Color.WHITE);
            setFont(Estilo.fonte(Font.PLAIN, 14));
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 10));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    sobre = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    sobre = false;
                    repaint();
                }
            });
        }

        void setAtivo(boolean ativo) {
            this.ativo = ativo;
            if (ativo) {
                setFont(Estilo.fonte(Font.BOLD, 14));
            } else {
                setFont(Estilo.fonte(Font.PLAIN, 14));
            }
            repaint();
        }

        @Override
        public void updateUI() {
            setUI(new BasicButtonUI());
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            if (ativo) {
                g2.setColor(Estilo.escuroHover);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.setColor(Estilo.destaque);
                g2.fillRoundRect(0, 8, 4, getHeight() - 16, 4, 4);
            } else if (sobre) {
                g2.setColor(new Color(0x262B40));
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private static class CartaoResumo extends JPanel {

        private final JLabel rotuloValor = new JLabel("0");

        CartaoResumo(String nome) {
            setOpaque(false);
            setLayout(new BorderLayout(0, 4));
            setBorder(BorderFactory.createEmptyBorder(16, 18, 14, 18));

            rotuloValor.setFont(Estilo.fonte(Font.BOLD, 28));
            rotuloValor.setForeground(Estilo.texto);

            JLabel rotuloNome = new JLabel(nome);
            rotuloNome.setFont(Estilo.fonte(Font.PLAIN, 13));
            rotuloNome.setForeground(Estilo.textoSuave);

            add(rotuloValor, BorderLayout.CENTER);
            add(rotuloNome, BorderLayout.SOUTH);
        }

        void setValor(String valor) {
            rotuloValor.setText(valor);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Color.WHITE);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
            g2.setColor(Estilo.borda);
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 14, 14);
            g2.setColor(Estilo.destaque);
            g2.fillRoundRect(18, 0, 36, 4, 4, 4);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    private static class ImagemCartao extends JPanel {

        private final BufferedImage imagem;
        private final String nomeArquivo;
        private final String rotuloPadrao;

        ImagemCartao(String nomeArquivo, String rotuloPadrao) {
            this.nomeArquivo = nomeArquivo;
            this.rotuloPadrao = rotuloPadrao;
            this.imagem = Imagens.carregar(nomeArquivo);
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
            g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

            int largura = getWidth();
            int altura = getHeight();
            g2.setClip(new RoundRectangle2D.Float(0, 0, largura, altura, 18, 18));

            if (imagem != null) {
                double escala = Math.max(largura / (double) imagem.getWidth(), altura / (double) imagem.getHeight());
                int desenhoLargura = (int) Math.ceil(imagem.getWidth() * escala);
                int desenhoAltura = (int) Math.ceil(imagem.getHeight() * escala);
                g2.drawImage(imagem, (largura - desenhoLargura) / 2, (altura - desenhoAltura) / 2,
                        desenhoLargura, desenhoAltura, null);
            } else {
                g2.setPaint(new GradientPaint(0, 0, Estilo.escuroHover, largura, altura, Estilo.escuro));
                g2.fillRect(0, 0, largura, altura);
                g2.setColor(Color.WHITE);
                g2.setFont(Estilo.fonte(Font.BOLD, 24));
                int larguraTexto = g2.getFontMetrics().stringWidth(rotuloPadrao);
                g2.drawString(rotuloPadrao, (largura - larguraTexto) / 2, altura / 2);
                g2.setColor(new Color(0x9AA0B5));
                g2.setFont(Estilo.fonte(Font.PLAIN, 12));
                String dica = "src/imagens/" + nomeArquivo;
                larguraTexto = g2.getFontMetrics().stringWidth(dica);
                g2.drawString(dica, (largura - larguraTexto) / 2, altura / 2 + 24);
            }
            g2.dispose();
        }
    }
}
