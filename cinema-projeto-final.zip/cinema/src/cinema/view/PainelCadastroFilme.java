package cinema.view;

import cinema.enums.Classificacao;
import cinema.enums.Genero;
import cinema.model.Filme;
import cinema.repository.Repositorio;
import cinema.service.ConsultaSessaoService;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.util.List;

public class PainelCadastroFilme extends JPanel {

    private final Repositorio<Filme, Integer> filmeRepositorio;
    private final ConsultaSessaoService consultaSessaoService;

    private final JTextField campoTitulo = new JTextField(20);
    private final JComboBox<Genero> comboGenero = new JComboBox<>(Genero.values());
    private final JComboBox<Classificacao> comboClassificacao = new JComboBox<>(Classificacao.values());
    private final JTextField campoDuracao = new JTextField(5);
    private final JTextField campoNota = new JTextField(5);

    private final DefaultTableModel modeloTabela = new DefaultTableModel(
            new Object[]{"Id", "Título", "Gênero", "Classificação", "Duração", "Nota"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable tabelaFilmes = new JTable(modeloTabela);

    private static int proximoId = 1;
    private Integer idSelecionado = null;
    private Integer idEmEdicao = null;

    public PainelCadastroFilme(Repositorio<Filme, Integer> filmeRepositorio, ConsultaSessaoService consultaSessaoService) {
        this.filmeRepositorio = filmeRepositorio;
        this.consultaSessaoService = consultaSessaoService;
        setLayout(new BorderLayout(10, 10));
        setBorder(Estilo.margemPainel());
        add(Estilo.cabecalho("Cadastro de Filmes", "Cadastre, altere e remova os filmes do cinema", criarPainelFormulario()), BorderLayout.NORTH);
        add(Estilo.rolagem(tabelaFilmes), BorderLayout.CENTER);
        add(criarPainelBotoes(), BorderLayout.SOUTH);
        atualizarTabela();
    }

    private JPanel criarPainelFormulario() {
        return Estilo.formulario(new String[]{"Título", "Gênero", "Classificação", "Duração (min)", "Nota"},
                campoTitulo, comboGenero, comboClassificacao, campoDuracao, campoNota);
    }

    private JPanel criarPainelBotoes() {
        JPanel painel = Estilo.barraBotoes();

        JButton botaoCadastrar = Estilo.botao("Cadastrar", Estilo.Tipo.primario);
        JButton botaoAlterar = Estilo.botao("Alterar", Estilo.Tipo.secundario);
        JButton botaoRemover = Estilo.botao("Remover", Estilo.Tipo.perigo);
        JButton botaoLimpar = Estilo.botao("Limpar", Estilo.Tipo.neutro);

        botaoCadastrar.addActionListener(e -> cadastrar());
        botaoAlterar.addActionListener(e -> alterar());
        botaoRemover.addActionListener(e -> remover());
        botaoLimpar.addActionListener(e -> limparFormulario());

        tabelaFilmes.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                registrarSelecao();
            }
        });

        painel.add(botaoCadastrar);
        painel.add(botaoAlterar);
        painel.add(botaoRemover);
        painel.add(botaoLimpar);
        return painel;
    }

    private void cadastrar() {
        int idRegistro = proximoId;
        if (idEmEdicao != null) {
            idRegistro = idEmEdicao;
        }
        Filme filme = lerFormulario(idRegistro);
        if (filme == null) {
            return;
        }
        if (idEmEdicao != null) {
            filmeRepositorio.buscarPorId(idEmEdicao).ifPresent(existente -> existente.atualizarDados(filme));
        } else {
            filmeRepositorio.salvar(filme);
            proximoId++;
        }
        atualizarTabela();
        limparFormulario();
    }

    private void alterar() {
        if (idSelecionado == null) {
            JOptionPane.showMessageDialog(this, "Selecione um filme na tabela para alterar.");
            return;
        }
        filmeRepositorio.buscarPorId(idSelecionado).ifPresent(filme -> {
            idEmEdicao = filme.getId();
            campoTitulo.setText(filme.getTitulo());
            comboGenero.setSelectedItem(filme.getGenero());
            comboClassificacao.setSelectedItem(filme.getClassificacao());
            campoDuracao.setText(String.valueOf(filme.getDuracaoMinutos()));
            campoNota.setText(String.valueOf(filme.getNota()));
        });
    }

    private void remover() {
        if (idSelecionado == null) {
            JOptionPane.showMessageDialog(this, "Selecione um filme na tabela para remover.");
            return;
        }
        Filme filme = filmeRepositorio.buscarPorId(idSelecionado).orElse(null);
        if (filme != null && consultaSessaoService.filmePossuiSessoes(filme)) {
            JOptionPane.showMessageDialog(this, "Este filme possui sessões cadastradas e não pode ser removido.");
            return;
        }
        filmeRepositorio.remover(idSelecionado);
        atualizarTabela();
        limparFormulario();
    }

    private Filme lerFormulario(int id) {
        String titulo = campoTitulo.getText().trim();
        if (titulo.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o título do filme.");
            return null;
        }

        int duracao;
        try {
            duracao = Integer.parseInt(campoDuracao.getText().trim());
            if (duracao <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Duração inválida.");
            return null;
        }

        double nota = 0.0;
        String textoNota = campoNota.getText().trim();
        if (!textoNota.isEmpty()) {
            try {
                nota = Double.parseDouble(textoNota);
                if (nota < 0 || nota > 10) {
                    throw new NumberFormatException();
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Nota inválida. Use um valor entre 0 e 10.");
                return null;
            }
        }

        Genero genero = (Genero) comboGenero.getSelectedItem();
        Classificacao classificacao = (Classificacao) comboClassificacao.getSelectedItem();

        return new Filme(id, titulo, genero, classificacao, duracao, nota);
    }

    private void registrarSelecao() {
        int linha = tabelaFilmes.getSelectedRow();
        if (linha < 0) {
            return;
        }
        idSelecionado = (int) modeloTabela.getValueAt(linha, 0);
    }

    private void limparFormulario() {
        campoTitulo.setText("");
        campoDuracao.setText("");
        campoNota.setText("");
        comboGenero.setSelectedIndex(0);
        comboClassificacao.setSelectedIndex(0);
        idSelecionado = null;
        idEmEdicao = null;
        tabelaFilmes.clearSelection();
    }

    private void atualizarTabela() {
        modeloTabela.setRowCount(0);
        List<Filme> filmes = filmeRepositorio.listarTodos();
        for (Filme filme : filmes) {
            modeloTabela.addRow(new Object[]{
                    filme.getId(),
                    filme.getTitulo(),
                    filme.getGenero(),
                    filme.getClassificacao(),
                    filme.getDuracaoMinutos(),
                    filme.getNota()
            });
        }
    }
}
