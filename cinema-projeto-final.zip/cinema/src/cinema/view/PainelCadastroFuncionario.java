package cinema.view;

import cinema.enums.Cargo;
import cinema.model.Funcionario;
import cinema.repository.Repositorio;
import cinema.service.ConsultaIngressoService;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;

public class PainelCadastroFuncionario extends JPanel {

    private final ConsultaIngressoService consultaIngressoService;
    private static final DateTimeFormatter formatoData = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final Repositorio<Funcionario, String> funcionarioRepositorio;

    private final JTextField campoNome = new JTextField(18);
    private final JTextField campoCpf = new JTextField(12);
    private final JTextField campoDataNascimento = new JTextField(10);
    private final JTextField campoTelefone = new JTextField(12);
    private final JComboBox<Cargo> comboCargo = new JComboBox<>(Cargo.values());
    private final JTextField campoSalario = new JTextField(8);

    private final DefaultTableModel modeloTabela = new DefaultTableModel(
            new Object[]{"CPF", "Nome", "Nascimento", "Telefone", "Cargo", "Salário"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable tabelaFuncionarios = new JTable(modeloTabela);

    private String cpfSelecionado = null;
    private String cpfEmEdicao = null;

    public PainelCadastroFuncionario(Repositorio<Funcionario, String> funcionarioRepositorio, ConsultaIngressoService consultaIngressoService) {
        this.funcionarioRepositorio = funcionarioRepositorio;
        this.consultaIngressoService = consultaIngressoService;
        setLayout(new BorderLayout(10, 10));
        setBorder(Estilo.margemPainel());
        add(Estilo.cabecalho("Cadastro de Funcionários", "Controle os funcionários e os seus cargos", criarPainelFormulario()), BorderLayout.NORTH);
        add(Estilo.rolagem(tabelaFuncionarios), BorderLayout.CENTER);
        add(criarPainelBotoes(), BorderLayout.SOUTH);
        atualizarTabela();
    }

    private JPanel criarPainelFormulario() {
        return Estilo.formulario(new String[]{"Nome", "CPF", "Nascimento", "Telefone", "Cargo", "Salário"},
                campoNome, campoCpf, campoDataNascimento, campoTelefone, comboCargo, campoSalario);
    }

    private JPanel criarPainelBotoes() {
        JPanel painel = Estilo.barraBotoes();

        JButton botaoCadastrar = Estilo.botao("Cadastrar", Estilo.Tipo.primario);
        JButton botaoAlterar = Estilo.botao("Alterar", Estilo.Tipo.secundario);
        JButton botaoRemover = Estilo.botao("Remover", Estilo.Tipo.perigo);
        JButton botaoLimpar = Estilo.botao("Limpar", Estilo.Tipo.neutro);

        botaoCadastrar.addActionListener(e -> cadastrar());
        botaoAlterar.addActionListener(e -> alterar());
        botaoRemover.addActionListener(e -> remover());
        botaoLimpar.addActionListener(e -> limparFormulario());

        tabelaFuncionarios.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                registrarSelecao();
            }
        });

        painel.add(botaoCadastrar);
        painel.add(botaoAlterar);
        painel.add(botaoRemover);
        painel.add(botaoLimpar);
        return painel;
    }

    private void cadastrar() {
        Funcionario funcionario = lerFormulario();
        if (funcionario == null) {
            return;
        }
        if (cpfEmEdicao != null) {
            funcionarioRepositorio.buscarPorId(cpfEmEdicao).ifPresent(existente -> existente.atualizarDados(funcionario));
        } else {
            if (funcionarioRepositorio.buscarPorId(funcionario.getCpf()).isPresent()) {
                JOptionPane.showMessageDialog(this, "Já existe um funcionário cadastrado com esse CPF.");
                return;
            }
            funcionarioRepositorio.salvar(funcionario);
        }
        atualizarTabela();
        limparFormulario();
    }

    private void alterar() {
        if (cpfSelecionado == null) {
            JOptionPane.showMessageDialog(this, "Selecione um funcionário na tabela para alterar.");
            return;
        }
        funcionarioRepositorio.buscarPorId(cpfSelecionado).ifPresent(funcionario -> {
            cpfEmEdicao = funcionario.getCpf();
            campoNome.setText(funcionario.getNome());
            campoCpf.setText(funcionario.getCpf());
            campoCpf.setEditable(false);
            campoDataNascimento.setText(funcionario.getDataNascimento().format(formatoData));
            campoTelefone.setText(funcionario.getTelefone());
            comboCargo.setSelectedItem(funcionario.getCargo());
            campoSalario.setText(String.valueOf(funcionario.getSalario()));
        });
    }

    private void remover() {
        if (cpfSelecionado == null) {
            JOptionPane.showMessageDialog(this, "Selecione um funcionário na tabela para remover.");
            return;
        }
        Funcionario funcionario = funcionarioRepositorio.buscarPorId(cpfSelecionado).orElse(null);
        if (funcionario != null && consultaIngressoService.funcionarioPossuiVendas(funcionario)) {
            JOptionPane.showMessageDialog(this, "Este funcionário já vendeu ingressos e não pode ser removido.");
            return;
        }
        funcionarioRepositorio.remover(cpfSelecionado);
        atualizarTabela();
        limparFormulario();
    }

    private Funcionario lerFormulario() {
        String nome = campoNome.getText().trim();
        if (nome.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Informe o nome do funcionário.");
            return null;
        }

        String cpf = campoCpf.getText().trim();
        if (cpf.length() != 11 || !cpf.chars().allMatch(Character::isDigit)) {
            JOptionPane.showMessageDialog(this, "CPF inválido. Informe apenas os 11 dígitos.");
            return null;
        }

        LocalDate dataNascimento;
        try {
            dataNascimento = LocalDate.parse(campoDataNascimento.getText().trim(), formatoData);
            if (dataNascimento.isAfter(LocalDate.now())) {
                throw new DateTimeParseException("data futura", campoDataNascimento.getText(), 0);
            }
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Data de nascimento inválida. Use o formato dd/MM/yyyy.");
            return null;
        }

        double salario;
        try {
            salario = Double.parseDouble(campoSalario.getText().trim());
            if (salario < 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Salário inválido.");
            return null;
        }

        String telefone = campoTelefone.getText().trim();
        Cargo cargo = (Cargo) comboCargo.getSelectedItem();

        return new Funcionario(nome, cpf, dataNascimento, telefone, cargo, salario);
    }

    private void registrarSelecao() {
        int linha = tabelaFuncionarios.getSelectedRow();
        if (linha < 0) {
            return;
        }
        cpfSelecionado = (String) modeloTabela.getValueAt(linha, 0);
    }

    private void limparFormulario() {
        campoNome.setText("");
        campoCpf.setText("");
        campoDataNascimento.setText("");
        campoTelefone.setText("");
        campoSalario.setText("");
        comboCargo.setSelectedIndex(0);
        cpfSelecionado = null;
        cpfEmEdicao = null;
        campoCpf.setEditable(true);
        tabelaFuncionarios.clearSelection();
    }

    private void atualizarTabela() {
        modeloTabela.setRowCount(0);
        List<Funcionario> funcionarios = funcionarioRepositorio.listarTodos();
        for (Funcionario funcionario : funcionarios) {
            modeloTabela.addRow(new Object[]{
                    funcionario.getCpf(),
                    funcionario.getNome(),
                    funcionario.getDataNascimento().format(formatoData),
                    funcionario.getTelefone(),
                    funcionario.getCargo(),
                    funcionario.getSalario()
            });
        }
    }
}
