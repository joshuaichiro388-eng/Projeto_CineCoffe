package cinema.view;

import cinema.enums.StatusIngresso;
import cinema.model.Funcionario;
import cinema.model.Ingresso;
import cinema.repository.Repositorio;
import cinema.service.VendaService;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class PainelVendaIngresso extends JPanel {

    private static final DateTimeFormatter formatoHorario = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final Repositorio<Ingresso, Integer> ingressoRepositorio;
    private final Repositorio<Funcionario, String> funcionarioRepositorio;
    private final VendaService vendaService;

    private final JComboBox<Ingresso> comboIngresso = new JComboBox<>();
    private final JComboBox<Funcionario> comboFuncionario = new JComboBox<>();

    private final DefaultTableModel modeloTabela = new DefaultTableModel(
            new Object[]{"Id", "Cliente", "Sessão", "Tipo", "Preço", "Vendido por", "Status"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable tabelaIngressos = new JTable(modeloTabela);

    public PainelVendaIngresso(Repositorio<Ingresso, Integer> ingressoRepositorio,
                               Repositorio<Funcionario, String> funcionarioRepositorio,
                               VendaService vendaService) {
        this.ingressoRepositorio = ingressoRepositorio;
        this.funcionarioRepositorio = funcionarioRepositorio;
        this.vendaService = vendaService;
        setLayout(new BorderLayout(10, 10));
        setBorder(Estilo.margemPainel());
        add(Estilo.cabecalho("Vender Ingresso", "Confirme a venda de um ingresso já reservado", criarPainelFormulario()), BorderLayout.NORTH);
        add(Estilo.rolagem(tabelaIngressos), BorderLayout.CENTER);
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                atualizarCombos();
                atualizarTabela();
            }
        });
        atualizarCombos();
        atualizarTabela();
    }

    private JPanel criarPainelFormulario() {
        JButton botaoVender = Estilo.botao("Vender Ingresso", Estilo.Tipo.primario);
        botaoVender.addActionListener(e -> vender());

        JPanel formulario = Estilo.formulario(new String[]{"Ingresso comprado", "Funcionário"},
                comboIngresso, comboFuncionario);
        return Estilo.linhaAcao(formulario, botaoVender);
    }

    private void vender() {
        Ingresso ingresso = (Ingresso) comboIngresso.getSelectedItem();
        Funcionario funcionario = (Funcionario) comboFuncionario.getSelectedItem();

        if (ingresso == null) {
            JOptionPane.showMessageDialog(this, "Não há ingressos comprados aguardando venda.");
            return;
        }
        if (funcionario == null) {
            JOptionPane.showMessageDialog(this, "É necessário ter ao menos um funcionário cadastrado.");
            return;
        }

        try {
            vendaService.venderIngresso(ingresso, funcionario);
            JOptionPane.showMessageDialog(this,
                    "Ingresso #" + ingresso.getId() + " vendido! Valor: R$ " + String.format("%.2f", ingresso.getPrecoFinal()));
            atualizarCombos();
            atualizarTabela();
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Não foi possível vender", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void atualizarCombos() {
        comboIngresso.removeAllItems();
        for (Ingresso ingresso : ingressoRepositorio.listarTodos()) {
            if (ingresso.getStatus() == StatusIngresso.reservado) {
                comboIngresso.addItem(ingresso);
            }
        }

        Funcionario funcionarioSelecionado = (Funcionario) comboFuncionario.getSelectedItem();
        comboFuncionario.removeAllItems();
        for (Funcionario funcionario : funcionarioRepositorio.listarTodos()) {
            comboFuncionario.addItem(funcionario);
        }
        if (funcionarioSelecionado != null) {
            comboFuncionario.setSelectedItem(funcionarioSelecionado);
        }
    }

    private void atualizarTabela() {
        modeloTabela.setRowCount(0);
        List<Ingresso> ingressos = ingressoRepositorio.listarTodos();
        for (Ingresso ingresso : ingressos) {
            String nomeFuncionario = "-";
            if (ingresso.getFuncionario() != null) {
                nomeFuncionario = ingresso.getFuncionario().getNome();
            }
            modeloTabela.addRow(new Object[]{
                    ingresso.getId(),
                    ingresso.getCliente().getNome(),
                    ingresso.getSessao().getFilme().getTitulo() + " - " + ingresso.getSessao().getHorario().format(formatoHorario),
                    ingresso.getDescricaoTipo(),
                    String.format("R$ %.2f", ingresso.getPrecoFinal()),
                    nomeFuncionario,
                    ingresso.getStatus()
            });
        }
    }
}
