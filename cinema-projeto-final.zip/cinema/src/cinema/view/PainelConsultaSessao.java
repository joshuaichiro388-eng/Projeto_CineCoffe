package cinema.view;

import cinema.enums.Genero;
import cinema.enums.TipoSala;
import cinema.model.Sessao;
import cinema.service.ConsultaSessaoService;
import cinema.util.Transformador;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.function.Predicate;

public class PainelConsultaSessao extends JPanel {

    private static final DateTimeFormatter formatoHorario = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final ConsultaSessaoService consultaSessaoService;

    private final JComboBox<Genero> comboGenero = new JComboBox<>();
    private final JComboBox<TipoSala> comboTipoSala = new JComboBox<>();
    private static final DateTimeFormatter formatoData = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final JTextField campoData = new JTextField(8);
    private final JCheckBox checkComVagas = new JCheckBox("Somente com vagas");
    private final JComboBox<String> comboOrdenacao = new JComboBox<>(new String[]{"Horário", "Nota do filme"});

    private final DefaultTableModel modeloTabela = new DefaultTableModel(
            new Object[]{"Filme", "Gênero", "Sala", "Horário", "Status", "Vagas", "Nota"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable tabelaSessoes = new JTable(modeloTabela);

    private final JLabel labelResumo = new JLabel(" ");

    public PainelConsultaSessao(ConsultaSessaoService consultaSessaoService) {
        this.consultaSessaoService = consultaSessaoService;
        setLayout(new BorderLayout(10, 10));
        setBorder(Estilo.margemPainel());
        add(criarPainelFiltros(), BorderLayout.NORTH);
        add(Estilo.rolagem(tabelaSessoes), BorderLayout.CENTER);
        add(Estilo.rodape(labelResumo), BorderLayout.SOUTH);
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                buscar();
            }
        });
        montarComboGenero();
        montarComboTipoSala();
    }

    private JPanel criarPainelFiltros() {
        JButton botaoBuscar = Estilo.botao("Buscar", Estilo.Tipo.primario);
        botaoBuscar.addActionListener(e -> buscar());

        JPanel filtros = Estilo.formulario(
                new String[]{"Gênero", "Sala", "Data (dd/MM/yyyy)", "Ordenar por", " "},
                comboGenero, comboTipoSala, campoData, comboOrdenacao, checkComVagas);
        return Estilo.cabecalho("Consulta de Sessões", "Filtre e ordene as sessões do cinema",
                Estilo.linhaAcao(filtros, botaoBuscar));
    }

    private void montarComboGenero() {
        comboGenero.addItem(null);
        for (Genero genero : Genero.values()) {
            comboGenero.addItem(genero);
        }
        comboGenero.setRenderer(Estilo.rendererComNulo("Todos os gêneros", valor -> valor.toString()));
    }

    private void montarComboTipoSala() {
        comboTipoSala.addItem(null);
        for (TipoSala tipoSala : TipoSala.values()) {
            comboTipoSala.addItem(tipoSala);
        }
        comboTipoSala.setRenderer(Estilo.rendererComNulo("Todos os tipos", valor -> valor.toString()));
    }

    private void buscar() {
        Predicate<Sessao> filtro = sessao -> true;

        Genero genero = (Genero) comboGenero.getSelectedItem();
        if (genero != null) {
            filtro = filtro.and(ConsultaSessaoService.porGenero(genero));
        }

        TipoSala tipoSala = (TipoSala) comboTipoSala.getSelectedItem();
        if (tipoSala != null) {
            filtro = filtro.and(ConsultaSessaoService.porTipoSala(tipoSala));
        }

        String textoData = campoData.getText().trim();
        if (!textoData.isEmpty()) {
            try {
                LocalDate data = LocalDate.parse(textoData, formatoData);
                filtro = filtro.and(ConsultaSessaoService.porData(data));
            } catch (DateTimeParseException ex) {
                JOptionPane.showMessageDialog(this, "Data inválida. Use o formato dd/MM/yyyy.");
                return;
            }
        }

        if (checkComVagas.isSelected()) {
            filtro = filtro.and(ConsultaSessaoService.comVagasDisponiveis());
        }

        List<Sessao> resultado = consultaSessaoService.filtrar(filtro);

        if ("Nota do filme".equals(comboOrdenacao.getSelectedItem())) {
            resultado = consultaSessaoService.ordenarPorNotaFilme(resultado);
        } else {
            resultado = consultaSessaoService.ordenarPorHorario(resultado);
        }

        atualizarTabela(resultado);
        atualizarResumo(resultado);
    }

    private void atualizarTabela(List<Sessao> sessoes) {
        modeloTabela.setRowCount(0);
        List<Object[]> linhas = Transformador.transformar(sessoes, sessao -> new Object[]{
                sessao.getFilme().getTitulo(),
                sessao.getFilme().getGenero(),
                sessao.getSala(),
                sessao.getHorario().format(formatoHorario),
                sessao.getStatus(),
                sessao.getVagasDisponiveis(),
                sessao.getFilme().getNota()
        });
        linhas.forEach(linha -> modeloTabela.addRow(linha));
    }

    private void atualizarResumo(List<Sessao> sessoes) {
        int totalVagas = sessoes.stream().mapToInt(Sessao::getVagasDisponiveis).sum();
        labelResumo.setText("Sessões encontradas: " + sessoes.size() + "   |   Total de vagas disponíveis: " + totalVagas);
    }
}
