package cinema.view;

import javax.swing.JPanel;
import javax.swing.JWindow;
import javax.swing.Timer;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;

public class TelaAbertura extends JWindow {

    private static final int duracaoMs = 3000;

    private final Runnable aoTerminar;
    private final BufferedImage logo = Imagens.carregar("logo.png");
    private float progresso = 0f;

    public TelaAbertura(Runnable aoTerminar) {
        this.aoTerminar = aoTerminar;
        setSize(640, 400);
        setLocationRelativeTo(null);
        setContentPane(new PainelAbertura());
    }

    public void exibir() {
        setVisible(true);
        long inicio = System.currentTimeMillis();
        Timer relogio = new Timer(30, null);
        relogio.addActionListener(e -> {
            progresso = Math.min(1f, (System.currentTimeMillis() - inicio) / (float) duracaoMs);
            repaint();
            if (progresso >= 1f) {
                relogio.stop();
                dispose();
                aoTerminar.run();
            }
        });
        relogio.start();
    }

    private class PainelAbertura extends JPanel {

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);

            int largura = getWidth();
            int altura = getHeight();
            g2.setPaint(new GradientPaint(0, 0, Estilo.escuroHover, 0, altura, Estilo.escuro));
            g2.fillRect(0, 0, largura, altura);

            if (logo != null) {
                desenharLogo(g2, largura, altura);
            } else {
                desenharTextoPadrao(g2, largura, altura);
            }
            desenharBarra(g2, largura, altura);
            g2.dispose();
        }

        private void desenharLogo(Graphics2D g2, int largura, int altura) {
            int areaLargura = largura - 120;
            int areaAltura = altura - 150;
            double escala = Math.min(areaLargura / (double) logo.getWidth(), areaAltura / (double) logo.getHeight());
            int logoLargura = (int) (logo.getWidth() * escala);
            int logoAltura = (int) (logo.getHeight() * escala);
            g2.drawImage(logo, (largura - logoLargura) / 2, 40 + (areaAltura - logoAltura) / 2,
                    logoLargura, logoAltura, null);
        }

        private void desenharTextoPadrao(Graphics2D g2, int largura, int altura) {
            g2.setFont(Estilo.fonte(Font.BOLD, 56));
            FontMetrics medidas = g2.getFontMetrics();
            String nome = "CineCoffe";
            int x = (largura - medidas.stringWidth(nome)) / 2;
            int y = altura / 2 - 10;
            g2.setColor(Color.WHITE);
            g2.drawString(nome, x, y);

            g2.setColor(Estilo.destaque);
            g2.fillRoundRect((largura - 120) / 2, y + 16, 120, 5, 5, 5);

            g2.setFont(Estilo.fonte(Font.PLAIN, 16));
            medidas = g2.getFontMetrics();
            String subtitulo = "Sistema de cinema";
            g2.setColor(new Color(0x9AA0B5));
            g2.drawString(subtitulo, (largura - medidas.stringWidth(subtitulo)) / 2, y + 52);
        }

        private void desenharBarra(Graphics2D g2, int largura, int altura) {
            int barraLargura = largura - 160;
            int x = 80;
            int y = altura - 48;
            g2.setColor(Estilo.escuroHover);
            g2.fillRoundRect(x, y, barraLargura, 6, 6, 6);
            g2.setColor(Estilo.destaque);
            g2.fillRoundRect(x, y, (int) (barraLargura * progresso), 6, 6, 6);
        }
    }
}
