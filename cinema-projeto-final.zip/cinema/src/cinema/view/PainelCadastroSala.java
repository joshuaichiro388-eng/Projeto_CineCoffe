package cinema.view;

import cinema.enums.TipoSala;
import cinema.model.Sala;
import cinema.repository.Repositorio;
import cinema.service.ConsultaSessaoService;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.util.List;

public class PainelCadastroSala extends JPanel {

    private final Repositorio<Sala, Integer> salaRepositorio;
    private final ConsultaSessaoService consultaSessaoService;

    private final JTextField campoNumero = new JTextField(5);
    private final JTextField campoCapacidade = new JTextField(5);
    private final JComboBox<TipoSala> comboTipoSala = new JComboBox<>(TipoSala.values());

    private final DefaultTableModel modeloTabela = new DefaultTableModel(
            new Object[]{"Id", "Número", "Capacidade", "Tipo"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable tabelaSalas = new JTable(modeloTabela);

    private static int proximoId = 1;
    private Integer idSelecionado = null;
    private Integer idEmEdicao = null;

    public PainelCadastroSala(Repositorio<Sala, Integer> salaRepositorio, ConsultaSessaoService consultaSessaoService) {
        this.salaRepositorio = salaRepositorio;
        this.consultaSessaoService = consultaSessaoService;
        setLayout(new BorderLayout(10, 10));
        setBorder(Estilo.margemPainel());
        add(Estilo.cabecalho("Cadastro de Salas", "Gerencie as salas e o tipo de cada uma (2D ou 3D)", criarPainelFormulario()), BorderLayout.NORTH);
        add(Estilo.rolagem(tabelaSalas), BorderLayout.CENTER);
        add(criarPainelBotoes(), BorderLayout.SOUTH);
        atualizarTabela();
    }

    private JPanel criarPainelFormulario() {
        return Estilo.formulario(new String[]{"Número", "Capacidade", "Tipo"},
                campoNumero, campoCapacidade, comboTipoSala);
    }

    private JPanel criarPainelBotoes() {
        JPanel painel = Estilo.barraBotoes();

        JButton botaoCadastrar = Estilo.botao("Cadastrar", Estilo.Tipo.primario);
        JButton botaoAlterar = Estilo.botao("Alterar", Estilo.Tipo.secundario);
        JButton botaoRemover = Estilo.botao("Remover", Estilo.Tipo.perigo);
        JButton botaoLimpar = Estilo.botao("Limpar", Estilo.Tipo.neutro);

        botaoCadastrar.addActionListener(e -> cadastrar());
        botaoAlterar.addActionListener(e -> alterar());
        botaoRemover.addActionListener(e -> remover());
        botaoLimpar.addActionListener(e -> limparFormulario());

        tabelaSalas.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                registrarSelecao();
            }
        });

        painel.add(botaoCadastrar);
        painel.add(botaoAlterar);
        painel.add(botaoRemover);
        painel.add(botaoLimpar);
        return painel;
    }

    private void cadastrar() {
        int idRegistro = proximoId;
        if (idEmEdicao != null) {
            idRegistro = idEmEdicao;
        }
        Sala sala = lerFormulario(idRegistro);
        if (sala == null) {
            return;
        }
        if (idEmEdicao != null) {
            Sala existente = salaRepositorio.buscarPorId(idEmEdicao).orElse(null);
            if (existente != null) {
                if (sala.getCapacidade() != existente.getCapacidade() && consultaSessaoService.salaPossuiSessoes(existente)) {
                    JOptionPane.showMessageDialog(this, "Não é possível alterar a capacidade de uma sala que já possui sessões.");
                    return;
                }
                existente.atualizarDados(sala);
            }
        } else {
            salaRepositorio.salvar(sala);
            proximoId++;
        }
        atualizarTabela();
        limparFormulario();
    }

    private void alterar() {
        if (idSelecionado == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma sala na tabela para alterar.");
            return;
        }
        salaRepositorio.buscarPorId(idSelecionado).ifPresent(sala -> {
            idEmEdicao = sala.getId();
            campoNumero.setText(String.valueOf(sala.getNumero()));
            campoCapacidade.setText(String.valueOf(sala.getCapacidade()));
            comboTipoSala.setSelectedItem(sala.getTipoSala());
        });
    }

    private void remover() {
        if (idSelecionado == null) {
            JOptionPane.showMessageDialog(this, "Selecione uma sala na tabela para remover.");
            return;
        }
        Sala sala = salaRepositorio.buscarPorId(idSelecionado).orElse(null);
        if (sala != null && consultaSessaoService.salaPossuiSessoes(sala)) {
            JOptionPane.showMessageDialog(this, "Esta sala possui sessões cadastradas e não pode ser removida.");
            return;
        }
        salaRepositorio.remover(idSelecionado);
        atualizarTabela();
        limparFormulario();
    }

    private Sala lerFormulario(int id) {
        int numero;
        int capacidade;
        try {
            numero = Integer.parseInt(campoNumero.getText().trim());
            if (numero <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Número de sala inválido.");
            return null;
        }
        try {
            capacidade = Integer.parseInt(campoCapacidade.getText().trim());
            if (capacidade <= 0) {
                throw new NumberFormatException();
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Capacidade inválida.");
            return null;
        }

        TipoSala tipoSala = (TipoSala) comboTipoSala.getSelectedItem();
        return new Sala(id, numero, capacidade, tipoSala);
    }

    private void registrarSelecao() {
        int linha = tabelaSalas.getSelectedRow();
        if (linha < 0) {
            return;
        }
        idSelecionado = (int) modeloTabela.getValueAt(linha, 0);
    }

    private void limparFormulario() {
        campoNumero.setText("");
        campoCapacidade.setText("");
        comboTipoSala.setSelectedIndex(0);
        idSelecionado = null;
        idEmEdicao = null;
        tabelaSalas.clearSelection();
    }

    private void atualizarTabela() {
        modeloTabela.setRowCount(0);
        List<Sala> salas = salaRepositorio.listarTodos();
        for (Sala sala : salas) {
            modeloTabela.addRow(new Object[]{
                    sala.getId(),
                    sala.getNumero(),
                    sala.getCapacidade(),
                    sala.getTipoSala()
            });
        }
    }
}
