package cinema.view;

import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListCellRenderer;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.function.Function;

/**
 * Centraliza as cores, fontes e componentes visuais do sistema,
 * para que todas as telas tenham a mesma aparência.
 */
public final class Estilo {

    public static final Color fundo = new Color(0xF4F5F7);
    public static final Color escuro = new Color(0x1E2130);
    public static final Color escuroHover = new Color(0x2C3148);
    public static final Color destaque = new Color(0xF5A623);
    public static final Color texto = new Color(0x1F2430);
    public static final Color textoSuave = new Color(0x6B7280);
    public static final Color borda = new Color(0xDDE1E7);
    public static final Color linhaAlternada = new Color(0xF0F2F6);
    public static final Color selecao = new Color(0xFFE3A8);

    public enum Tipo {
        primario, secundario, perigo, neutro
    }

    private static final String familia = escolherFamilia();

    private Estilo() {
    }

    private static String escolherFamilia() {
        String[] preferidas = {"Segoe UI", "Helvetica Neue", "Ubuntu", "Noto Sans"};
        Set<String> instaladas = new HashSet<>(Arrays.asList(
                GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()));
        for (String nome : preferidas) {
            if (instaladas.contains(nome)) {
                return nome;
            }
        }
        return Font.SANS_SERIF;
    }

    public static Font fonte(int estilo, float tamanho) {
        return new Font(familia, estilo, 13).deriveFont(estilo, tamanho);
    }

    public static void aplicarTema() {
        UIManager.put("control", fundo);
        UIManager.put("nimbusBase", new Color(0x3A4160));
        UIManager.put("nimbusFocus", destaque);
        UIManager.put("defaultFont", fonte(Font.PLAIN, 13));
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ex) {
            // se o tema não puder ser aplicado, o Java usa o visual padrão
        }
    }

    public static Border margemPainel() {
        return BorderFactory.createEmptyBorder(18, 22, 18, 22);
    }

    public static JPanel cabecalho(String titulo, String subtitulo, JComponent conteudo) {
        JPanel textos = new JPanel(new BorderLayout(0, 2));
        textos.setOpaque(false);
        JLabel rotuloTitulo = new JLabel(titulo);
        rotuloTitulo.setFont(fonte(Font.BOLD, 22));
        rotuloTitulo.setForeground(texto);
        JLabel rotuloSubtitulo = new JLabel(subtitulo);
        rotuloSubtitulo.setFont(fonte(Font.PLAIN, 13));
        rotuloSubtitulo.setForeground(textoSuave);
        textos.add(rotuloTitulo, BorderLayout.NORTH);
        textos.add(rotuloSubtitulo, BorderLayout.CENTER);

        JPanel cartao = new JPanel(new BorderLayout());
        cartao.setBackground(Color.WHITE);
        cartao.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borda),
                BorderFactory.createEmptyBorder(14, 16, 16, 16)));
        cartao.add(conteudo, BorderLayout.CENTER);

        JPanel raiz = new JPanel(new BorderLayout(0, 14));
        raiz.setOpaque(false);
        raiz.add(textos, BorderLayout.NORTH);
        raiz.add(cartao, BorderLayout.CENTER);
        return raiz;
    }

    public static JPanel formulario(String[] rotulos, JComponent... campos) {
        double[] pesos = new double[campos.length];
        Arrays.fill(pesos, 1.0);
        return formulario(rotulos, pesos, campos);
    }

    public static JPanel formulario(String[] rotulos, double[] pesos, JComponent... campos) {
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setOpaque(false);
        for (int i = 0; i < campos.length; i++) {
            int espaco = 14;
            if (i == campos.length - 1) {
                espaco = 0;
            }

            JLabel rotulo = new JLabel(rotulos[i]);
            rotulo.setFont(fonte(Font.BOLD, 12));
            rotulo.setForeground(textoSuave);
            GridBagConstraints posicaoRotulo = new GridBagConstraints();
            posicaoRotulo.gridx = i;
            posicaoRotulo.gridy = 0;
            posicaoRotulo.anchor = GridBagConstraints.WEST;
            posicaoRotulo.insets = new Insets(0, 0, 4, espaco);
            painel.add(rotulo, posicaoRotulo);

            JComponent campo = campos[i];
            if (!(campo instanceof JCheckBox)) {
                campo.setMinimumSize(new Dimension(130, campo.getMinimumSize().height));
            }
            GridBagConstraints posicaoCampo = new GridBagConstraints();
            posicaoCampo.gridx = i;
            posicaoCampo.gridy = 1;
            posicaoCampo.weightx = pesos[i];
            posicaoCampo.fill = GridBagConstraints.HORIZONTAL;
            posicaoCampo.ipady = 6;
            posicaoCampo.insets = new Insets(0, 0, 0, espaco);
            painel.add(campo, posicaoCampo);
        }
        return painel;
    }

    public static JPanel linhaAcao(JComponent formulario, JComponent acao) {
        JPanel lado = new JPanel(new BorderLayout());
        lado.setOpaque(false);
        lado.add(acao, BorderLayout.SOUTH);

        JPanel painel = new JPanel(new BorderLayout(14, 0));
        painel.setOpaque(false);
        painel.add(formulario, BorderLayout.CENTER);
        painel.add(lado, BorderLayout.EAST);
        return painel;
    }

    public static JPanel barraBotoes() {
        JPanel painel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 10));
        painel.setOpaque(false);
        return painel;
    }

    public static JPanel rodape(JLabel rotulo) {
        rotulo.setFont(fonte(Font.BOLD, 13));
        rotulo.setForeground(texto);
        JPanel painel = new JPanel(new BorderLayout());
        painel.setBackground(Color.WHITE);
        painel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(borda),
                BorderFactory.createEmptyBorder(10, 14, 10, 14)));
        painel.add(rotulo, BorderLayout.CENTER);
        return painel;
    }

    public static JScrollPane rolagem(JTable tabela) {
        estilizarTabela(tabela);
        JScrollPane rolagem = new JScrollPane(tabela);
        rolagem.setBorder(BorderFactory.createLineBorder(borda));
        rolagem.getViewport().setBackground(Color.WHITE);
        return rolagem;
    }

    public static <T> ListCellRenderer<T> rendererComNulo(String textoNulo, Function<T, String> descricao) {
        DefaultListCellRenderer base = new DefaultListCellRenderer();
        return (lista, valor, indice, selecionado, foco) -> {
            JLabel rotulo = (JLabel) base.getListCellRendererComponent(lista, valor, indice, selecionado, foco);
            if (valor == null) {
                rotulo.setText(textoNulo);
            } else {
                rotulo.setText(descricao.apply(valor));
            }
            return rotulo;
        };
    }

    public static JButton botao(String rotulo, Tipo tipo) {
        return new Botao(rotulo, tipo);
    }

    private static void estilizarTabela(JTable tabela) {
        tabela.setRowHeight(30);
        tabela.setShowGrid(false);
        tabela.setIntercellSpacing(new Dimension(0, 0));
        tabela.setFillsViewportHeight(true);
        tabela.setFont(fonte(Font.PLAIN, 13));
        tabela.setSelectionBackground(selecao);
        tabela.setSelectionForeground(texto);
        tabela.setDefaultRenderer(Object.class, new RendererLinha());

        JTableHeader cabecalho = tabela.getTableHeader();
        cabecalho.setReorderingAllowed(false);
        cabecalho.setDefaultRenderer(new RendererCabecalho());
        cabecalho.setPreferredSize(new Dimension(0, 34));

        tabela.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        tabela.getModel().addTableModelListener(e -> SwingUtilities.invokeLater(() -> ajustarLarguras(tabela)));
    }

    private static void ajustarLarguras(JTable tabela) {
        for (int coluna = 0; coluna < tabela.getColumnCount(); coluna++) {
            TableColumn tc = tabela.getColumnModel().getColumn(coluna);
            Component titulo = tabela.getTableHeader().getDefaultRenderer()
                    .getTableCellRendererComponent(tabela, tc.getHeaderValue(), false, false, -1, coluna);
            int largura = titulo.getPreferredSize().width;
            for (int linha = 0; linha < tabela.getRowCount(); linha++) {
                Component celula = tabela.prepareRenderer(tabela.getCellRenderer(linha, coluna), linha, coluna);
                largura = Math.max(largura, celula.getPreferredSize().width);
            }
            tc.setPreferredWidth(Math.min(largura + 24, 420));
        }
    }

    private static class RendererLinha extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable tabela, Object valor, boolean selecionada,
                                                       boolean foco, int linha, int coluna) {
            super.getTableCellRendererComponent(tabela, valor, selecionada, false, linha, coluna);
            setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
            setForeground(texto);
            if (selecionada) {
                setBackground(selecao);
            } else if (linha % 2 == 0) {
                setBackground(Color.WHITE);
            } else {
                setBackground(linhaAlternada);
            }
            return this;
        }
    }

    private static class RendererCabecalho extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable tabela, Object valor, boolean selecionada,
                                                       boolean foco, int linha, int coluna) {
            super.getTableCellRendererComponent(tabela, valor, false, false, linha, coluna);
            setOpaque(true);
            setBackground(escuro);
            setForeground(Color.WHITE);
            setFont(fonte(Font.BOLD, 12));
            setHorizontalAlignment(LEFT);
            setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
            return this;
        }
    }

    private static class Botao extends JButton {

        private final Color corBase;
        private final Color corHover;
        private boolean sobre = false;

        Botao(String rotulo, Tipo tipo) {
            super(rotulo);
            this.corBase = switch (tipo) {
                case primario -> destaque;
                case secundario -> new Color(0x455A64);
                case perigo -> new Color(0xC62828);
                case neutro -> new Color(0xE3E6EB);
            };
            this.corHover = switch (tipo) {
                case primario -> new Color(0xD98E12);
                case secundario -> new Color(0x37474F);
                case perigo -> new Color(0xA81F1F);
                case neutro -> new Color(0xD3D8DF);
            };
            if (tipo == Tipo.secundario || tipo == Tipo.perigo) {
                setForeground(Color.WHITE);
            } else {
                setForeground(texto);
            }
            setFont(fonte(Font.BOLD, 13));
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setBorder(BorderFactory.createEmptyBorder(9, 20, 9, 20));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    sobre = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    sobre = false;
                    repaint();
                }
            });
        }

        @Override
        public void updateUI() {
            setUI(new BasicButtonUI());
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            Color cor = corBase;
            if (!isEnabled()) {
                cor = new Color(0xC9CDD4);
            } else if (getModel().isPressed()) {
                cor = corHover.darker();
            } else if (sobre) {
                cor = corHover;
            }
            g2.setColor(cor);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
            g2.dispose();
            super.paintComponent(g);
        }
    }
}
