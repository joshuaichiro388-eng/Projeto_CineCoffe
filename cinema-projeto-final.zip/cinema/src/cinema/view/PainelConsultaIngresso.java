package cinema.view;

import cinema.enums.StatusIngresso;
import cinema.model.Cliente;
import cinema.model.Ingresso;
import cinema.repository.Repositorio;
import cinema.service.ConsultaIngressoService;
import cinema.util.Transformador;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.function.Predicate;

public class PainelConsultaIngresso extends JPanel {

    private static final DateTimeFormatter formatoDataHora = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final ConsultaIngressoService consultaIngressoService;
    private final Repositorio<Cliente, String> clienteRepositorio;

    private final JComboBox<StatusIngresso> comboStatus = new JComboBox<>();
    private final JComboBox<Cliente> comboCliente = new JComboBox<>();
    private final JComboBox<String> comboOrdenacao = new JComboBox<>(new String[]{"Data da compra", "Preço"});

    private final DefaultTableModel modeloTabela = new DefaultTableModel(
            new Object[]{"Id", "Cliente", "Sessão", "Tipo", "Preço", "Status", "Data da compra", "Data da venda"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable tabelaIngressos = new JTable(modeloTabela);

    private final JLabel labelResumo = new JLabel(" ");

    public PainelConsultaIngresso(ConsultaIngressoService consultaIngressoService,
                                   Repositorio<Cliente, String> clienteRepositorio) {
        this.consultaIngressoService = consultaIngressoService;
        this.clienteRepositorio = clienteRepositorio;
        setLayout(new BorderLayout(10, 10));
        setBorder(Estilo.margemPainel());
        add(criarPainelFiltros(), BorderLayout.NORTH);
        add(Estilo.rolagem(tabelaIngressos), BorderLayout.CENTER);
        add(Estilo.rodape(labelResumo), BorderLayout.SOUTH);
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                atualizarComboCliente();
                buscar();
            }
        });
        montarComboStatus();
    }

    private JPanel criarPainelFiltros() {
        JButton botaoBuscar = Estilo.botao("Buscar", Estilo.Tipo.primario);
        botaoBuscar.addActionListener(e -> buscar());

        JPanel filtros = Estilo.formulario(
                new String[]{"Status", "Cliente", "Ordenar por"},
                comboStatus, comboCliente, comboOrdenacao);
        return Estilo.cabecalho("Consulta de Ingressos", "Filtre os ingressos por status e por cliente",
                Estilo.linhaAcao(filtros, botaoBuscar));
    }

    private void montarComboStatus() {
        comboStatus.addItem(null);
        for (StatusIngresso status : StatusIngresso.values()) {
            comboStatus.addItem(status);
        }
        comboStatus.setRenderer(Estilo.rendererComNulo("Todos os status", valor -> valor.toString()));
    }

    private void atualizarComboCliente() {
        Cliente clienteSelecionado = (Cliente) comboCliente.getSelectedItem();
        comboCliente.removeAllItems();
        comboCliente.addItem(null);
        for (Cliente cliente : clienteRepositorio.listarTodos()) {
            comboCliente.addItem(cliente);
        }
        comboCliente.setSelectedItem(clienteSelecionado);
        comboCliente.setRenderer(Estilo.rendererComNulo("Todos os clientes", valor -> valor.getNome()));
    }

    private void buscar() {
        Predicate<Ingresso> filtro = ingresso -> true;

        StatusIngresso status = (StatusIngresso) comboStatus.getSelectedItem();
        if (status != null) {
            filtro = filtro.and(ConsultaIngressoService.porStatus(status));
        }

        Cliente cliente = (Cliente) comboCliente.getSelectedItem();
        if (cliente != null) {
            filtro = filtro.and(ConsultaIngressoService.porCliente(cliente));
        }

        List<Ingresso> resultado = consultaIngressoService.filtrar(filtro);

        if ("Preço".equals(comboOrdenacao.getSelectedItem())) {
            resultado = consultaIngressoService.ordenarPorPreco(resultado);
        } else {
            resultado = consultaIngressoService.ordenarPorData(resultado);
        }

        atualizarTabela(resultado);
        atualizarResumo(resultado);
    }

    private void atualizarTabela(List<Ingresso> ingressos) {
        modeloTabela.setRowCount(0);
        List<Object[]> linhas = Transformador.transformar(ingressos, ingresso -> {
            String dataVenda = "-";
            if (ingresso.getDataVenda() != null) {
                dataVenda = ingresso.getDataVenda().format(formatoDataHora);
            }
            return new Object[]{
                    ingresso.getId(),
                    ingresso.getCliente().getNome(),
                    ingresso.getSessao().getFilme().getTitulo() + " - " + ingresso.getSessao().getHorario().format(formatoDataHora),
                    ingresso.getDescricaoTipo(),
                    String.format("R$ %.2f", ingresso.getPrecoFinal()),
                    ingresso.getStatus(),
                    ingresso.getDataCompra().format(formatoDataHora),
                    dataVenda
            };
        });
        linhas.forEach(linha -> modeloTabela.addRow(linha));
    }

    private void atualizarResumo(List<Ingresso> ingressos) {
        double faturamento = ingressos.stream()
                .filter(i -> i.getStatus() == StatusIngresso.pago)
                .mapToDouble(Ingresso::getPrecoFinal)
                .sum();
        labelResumo.setText("Ingressos encontrados: " + ingressos.size()
                + "   |   Faturamento (ingressos vendidos): R$ " + String.format("%.2f", faturamento));
    }
}
