package cinema.view;

import cinema.enums.StatusSessao;
import cinema.model.Cliente;
import cinema.model.Ingresso;
import cinema.model.Sessao;
import cinema.repository.Repositorio;
import cinema.service.VendaService;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class PainelCompraIngresso extends JPanel {

    private static final DateTimeFormatter formatoHorario = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final Repositorio<Sessao, Integer> sessaoRepositorio;
    private final Repositorio<Cliente, String> clienteRepositorio;
    private final Repositorio<Ingresso, Integer> ingressoRepositorio;
    private final VendaService vendaService;

    private final JComboBox<Sessao> comboSessao = new JComboBox<>();
    private final JComboBox<Cliente> comboCliente = new JComboBox<>();
    private final JCheckBox checkMeiaEntrada = new JCheckBox("Meia-entrada");

    private final DefaultTableModel modeloTabela = new DefaultTableModel(
            new Object[]{"Id", "Cliente", "Sessão", "Tipo", "Preço", "Status"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable tabelaIngressos = new JTable(modeloTabela);

    public PainelCompraIngresso(Repositorio<Sessao, Integer> sessaoRepositorio,
                                Repositorio<Cliente, String> clienteRepositorio,
                                Repositorio<Ingresso, Integer> ingressoRepositorio,
                                VendaService vendaService) {
        this.sessaoRepositorio = sessaoRepositorio;
        this.clienteRepositorio = clienteRepositorio;
        this.ingressoRepositorio = ingressoRepositorio;
        this.vendaService = vendaService;
        setLayout(new BorderLayout(10, 10));
        setBorder(Estilo.margemPainel());
        add(Estilo.cabecalho("Comprar Ingresso", "Escolha a sessão e o cliente para reservar um ingresso", criarPainelFormulario()), BorderLayout.NORTH);
        add(Estilo.rolagem(tabelaIngressos), BorderLayout.CENTER);
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                atualizarCombos();
                atualizarTabela();
            }
        });
        atualizarCombos();
        atualizarTabela();
    }

    private JPanel criarPainelFormulario() {
        JButton botaoComprar = Estilo.botao("Comprar Ingresso", Estilo.Tipo.primario);
        botaoComprar.addActionListener(e -> comprar());

        JPanel formulario = Estilo.formulario(new String[]{"Sessão", "Cliente", " "}, new double[]{3, 2, 0},
                comboSessao, comboCliente, checkMeiaEntrada);
        return Estilo.linhaAcao(formulario, botaoComprar);
    }

    private void comprar() {
        Sessao sessao = (Sessao) comboSessao.getSelectedItem();
        Cliente cliente = (Cliente) comboCliente.getSelectedItem();

        if (sessao == null || cliente == null) {
            JOptionPane.showMessageDialog(this,
                    "É necessário ter ao menos uma sessão e um cliente cadastrados.");
            return;
        }

        try {
            Ingresso ingresso;
            if (checkMeiaEntrada.isSelected()) {
                ingresso = vendaService.comprarIngresso(sessao, cliente, true);
            } else {
                ingresso = vendaService.comprarIngresso(sessao, cliente);
            }
            JOptionPane.showMessageDialog(this,
                    "Ingresso comprado com sucesso!\n" + ingresso.getDescricaoTipo() + " - Sala "
                            + sessao.getSala().getTipoSala() + " - R$ " + String.format("%.2f", ingresso.getPrecoFinal()));
            checkMeiaEntrada.setSelected(false);
            atualizarCombos();
            atualizarTabela();
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Não foi possível comprar", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void atualizarCombos() {
        Sessao sessaoSelecionada = (Sessao) comboSessao.getSelectedItem();
        comboSessao.removeAllItems();
        for (Sessao sessao : sessaoRepositorio.listarTodos()) {
            if (sessao.getStatus() != StatusSessao.encerrada && sessao.getStatus() != StatusSessao.cancelada) {
                comboSessao.addItem(sessao);
            }
        }
        if (sessaoSelecionada != null) {
            comboSessao.setSelectedItem(sessaoSelecionada);
        }

        Cliente clienteSelecionado = (Cliente) comboCliente.getSelectedItem();
        comboCliente.removeAllItems();
        for (Cliente cliente : clienteRepositorio.listarTodos()) {
            comboCliente.addItem(cliente);
        }
        if (clienteSelecionado != null) {
            comboCliente.setSelectedItem(clienteSelecionado);
        }
    }

    private void atualizarTabela() {
        modeloTabela.setRowCount(0);
        List<Ingresso> ingressos = ingressoRepositorio.listarTodos();
        for (Ingresso ingresso : ingressos) {
            modeloTabela.addRow(new Object[]{
                    ingresso.getId(),
                    ingresso.getCliente().getNome(),
                    ingresso.getSessao().getFilme().getTitulo() + " - " + ingresso.getSessao().getHorario().format(formatoHorario),
                    ingresso.getDescricaoTipo(),
                    String.format("R$ %.2f", ingresso.getPrecoFinal()),
                    ingresso.getStatus()
            });
        }
    }
}
