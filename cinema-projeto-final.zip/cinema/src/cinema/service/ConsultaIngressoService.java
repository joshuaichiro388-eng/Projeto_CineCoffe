package cinema.service;

import cinema.enums.StatusIngresso;
import cinema.model.Cliente;
import cinema.model.Funcionario;
import cinema.model.Ingresso;
import cinema.model.Sessao;
import cinema.repository.Repositorio;

import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ConsultaIngressoService {

    private final Repositorio<Ingresso, Integer> ingressoRepositorio;

    public ConsultaIngressoService(Repositorio<Ingresso, Integer> ingressoRepositorio) {
        this.ingressoRepositorio = ingressoRepositorio;
    }

    public static Predicate<Ingresso> porStatus(StatusIngresso status) {
        return i -> i.getStatus() == status;
    }

    public static Predicate<Ingresso> porCliente(Cliente cliente) {
        return i -> i.getCliente().getCpf().equals(cliente.getCpf());
    }

    public boolean sessaoPossuiIngressos(Sessao sessao) {
        return ingressoRepositorio.listarTodos().stream()
                .anyMatch(i -> i.getSessao().getId() == sessao.getId());
    }

    public boolean clientePossuiIngressos(Cliente cliente) {
        return ingressoRepositorio.listarTodos().stream()
                .anyMatch(porCliente(cliente));
    }

    public boolean funcionarioPossuiVendas(Funcionario funcionario) {
        return ingressoRepositorio.listarTodos().stream()
                .anyMatch(i -> i.getFuncionario() != null
                        && i.getFuncionario().getCpf().equals(funcionario.getCpf()));
    }

    public List<Ingresso> filtrar(Predicate<Ingresso> filtro) {
        return ingressoRepositorio.listarTodos().stream()
                .filter(filtro)
                .collect(Collectors.toList());
    }

    public List<Ingresso> ordenarPorData(List<Ingresso> ingressos) {
        return ingressos.stream()
                .sorted(Comparator.comparing(Ingresso::getDataCompra).reversed())
                .collect(Collectors.toList());
    }

    public List<Ingresso> ordenarPorPreco(List<Ingresso> ingressos) {
        return ingressos.stream()
                .sorted(Comparator.comparingDouble(Ingresso::getPrecoFinal))
                .collect(Collectors.toList());
    }
}
