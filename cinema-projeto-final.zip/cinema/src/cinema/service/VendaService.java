package cinema.service;

import cinema.enums.StatusIngresso;
import cinema.enums.StatusSessao;
import cinema.model.Cliente;
import cinema.model.Funcionario;
import cinema.model.Ingresso;
import cinema.model.IngressoInteira;
import cinema.model.IngressoMeia;
import cinema.model.Sala;
import cinema.model.Sessao;
import cinema.repository.Repositorio;

import java.util.function.Function;

public class VendaService {

    private static final double precoBase = 20.0;
    private static final int idadeLimiteMeiaJovem = 18;
    private static final int idadeMinimaMeiaIdoso = 60;

    private final Repositorio<Ingresso, Integer> ingressoRepositorio;

    private final Function<Sala, Double> calculadoraPrecoBase =
            sala -> precoBase * sala.getTipoSala().getMultiplicadorPreco();

    public VendaService(Repositorio<Ingresso, Integer> ingressoRepositorio) {
        this.ingressoRepositorio = ingressoRepositorio;
    }

    public Ingresso comprarIngresso(Sessao sessao, Cliente cliente) {
        return comprarIngresso(sessao, cliente, false);
    }

    public Ingresso comprarIngresso(Sessao sessao, Cliente cliente, boolean meiaEntrada) {
        if (sessao.getStatus() == StatusSessao.encerrada || sessao.getStatus() == StatusSessao.cancelada) {
            throw new IllegalStateException("Não é possível comprar ingresso para uma sessão " + sessao.getStatus());
        }
        if (sessao.getVagasDisponiveis() <= 0) {
            throw new IllegalStateException("Sessão sem vagas disponíveis");
        }
        if (!sessao.getFilme().getClassificacao().permiteIdade(cliente.getIdade())) {
            throw new IllegalStateException("Cliente não atende a classificação etária do filme");
        }

        if (meiaEntrada && !temDireitoAMeia(cliente)) {
            throw new IllegalStateException("Meia-entrada só para clientes com menos de "
                    + idadeLimiteMeiaJovem + " anos ou com " + idadeMinimaMeiaIdoso + " anos ou mais");
        }

        double precoBaseSessao = calculadoraPrecoBase.apply(sessao.getSala());

        Ingresso ingresso;
        if (meiaEntrada) {
            ingresso = new IngressoMeia(sessao, cliente);
        } else {
            ingresso = new IngressoInteira(sessao, cliente);
        }
        ingresso.setPrecoFinal(ingresso.calcularPreco(precoBaseSessao));

        sessao.ocuparVaga();
        ingressoRepositorio.salvar(ingresso);
        return ingresso;
    }

    private boolean temDireitoAMeia(Cliente cliente) {
        int idade = cliente.getIdade();
        return idade < idadeLimiteMeiaJovem || idade >= idadeMinimaMeiaIdoso;
    }

    public void venderIngresso(Ingresso ingresso, Funcionario funcionario) {
        if (ingresso.getStatus() != StatusIngresso.reservado) {
            throw new IllegalStateException("Somente ingressos comprados e ainda não vendidos podem ser vendidos");
        }
        StatusSessao statusSessao = ingresso.getSessao().getStatus();
        if (statusSessao == StatusSessao.encerrada || statusSessao == StatusSessao.cancelada) {
            throw new IllegalStateException("Não é possível vender ingresso de uma sessão " + statusSessao);
        }

        ingresso.confirmarVenda(funcionario);
        ingressoRepositorio.atualizar(ingresso);
    }
}
