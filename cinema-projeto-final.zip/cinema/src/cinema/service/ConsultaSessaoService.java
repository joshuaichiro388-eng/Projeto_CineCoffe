package cinema.service;

import cinema.enums.Genero;
import cinema.enums.TipoSala;
import cinema.model.Filme;
import cinema.model.Sala;
import cinema.model.Sessao;
import cinema.repository.Repositorio;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class ConsultaSessaoService {

    private final Repositorio<Sessao, Integer> sessaoRepositorio;

    public ConsultaSessaoService(Repositorio<Sessao, Integer> sessaoRepositorio) {
        this.sessaoRepositorio = sessaoRepositorio;
    }

    public static Predicate<Sessao> porGenero(Genero genero) {
        return s -> s.getFilme().getGenero() == genero;
    }

    public static Predicate<Sessao> porData(LocalDate data) {
        return s -> s.getHorario().toLocalDate().equals(data);
    }

    public static Predicate<Sessao> porTipoSala(TipoSala tipoSala) {
        return s -> s.getSala().getTipoSala() == tipoSala;
    }

    public static Predicate<Sessao> comVagasDisponiveis() {
        return s -> s.getVagasDisponiveis() > 0;
    }

    public boolean filmePossuiSessoes(Filme filme) {
        return sessaoRepositorio.listarTodos().stream()
                .anyMatch(s -> s.getFilme().getId() == filme.getId());
    }

    public boolean salaPossuiSessoes(Sala sala) {
        return sessaoRepositorio.listarTodos().stream()
                .anyMatch(s -> s.getSala().getId() == sala.getId());
    }

    public List<Sessao> filtrar(Predicate<Sessao> filtro) {
        return sessaoRepositorio.listarTodos().stream()
                .filter(filtro)
                .collect(Collectors.toList());
    }

    public List<Sessao> filtrarDisponiveisPorGenero(Genero genero) {
        Predicate<Sessao> filtro = porGenero(genero).and(comVagasDisponiveis());
        return filtrar(filtro);
    }

    public List<Sessao> ordenarPorHorario(List<Sessao> sessoes) {
        return sessoes.stream()
                .sorted(Comparator.comparing(Sessao::getHorario))
                .collect(Collectors.toList());
    }

    public List<Sessao> ordenarPorNotaFilme(List<Sessao> sessoes) {
        return sessoes.stream()
                .sorted(Comparator.comparingDouble((Sessao s) -> s.getFilme().getNota()).reversed())
                .collect(Collectors.toList());
    }
}
