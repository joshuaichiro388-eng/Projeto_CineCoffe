package cinema.enums;

public enum StatusIngresso {
    reservado("Reservado"),
    pago("Pago"),
    utilizado("Utilizado");

    private final String descricao;

    StatusIngresso(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
