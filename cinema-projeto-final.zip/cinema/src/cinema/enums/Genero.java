package cinema.enums;

public enum Genero {
    acao("Ação"),
    comedia("Comédia"),
    drama("Drama"),
    terror("Terror"),
    ficcaoCientifica("Ficção Científica"),
    animacao("Animação"),
    romance("Romance"),
    documentario("Documentário");

    private final String descricao;

    Genero(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
