package cinema.enums;

public enum Cargo {
    atendente("Atendente"),
    gerente("Gerente");

    private final String descricao;

    Cargo(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
