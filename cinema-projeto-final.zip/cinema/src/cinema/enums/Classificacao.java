package cinema.enums;

public enum Classificacao {
    livre(0),
    dezAnos(10),
    dozeAnos(12),
    quatorzeAnos(14),
    dezesseisAnos(16),
    dezoitoAnos(18);

    private final int idadeMinima;

    Classificacao(int idadeMinima) {
        this.idadeMinima = idadeMinima;
    }

    public int getIdadeMinima() {
        return idadeMinima;
    }

    public boolean permiteIdade(int idadeCliente) {
        return idadeCliente >= idadeMinima;
    }

    @Override
    public String toString() {
        if (idadeMinima == 0) {
            return "Livre";
        }
        return idadeMinima + " anos";
    }
}
