package cinema.enums;

public enum TipoSala {
    duasD("2D", 1.0),
    tresD("3D", 1.3);

    private final String descricao;
    private final double multiplicadorPreco;

    TipoSala(String descricao, double multiplicadorPreco) {
        this.descricao = descricao;
        this.multiplicadorPreco = multiplicadorPreco;
    }

    public double getMultiplicadorPreco() {
        return multiplicadorPreco;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
