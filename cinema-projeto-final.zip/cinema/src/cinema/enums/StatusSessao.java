package cinema.enums;

public enum StatusSessao {
    agendada("Agendada"),
    emCartaz("Em cartaz"),
    encerrada("Encerrada"),
    cancelada("Cancelada");

    private final String descricao;

    StatusSessao(String descricao) {
        this.descricao = descricao;
    }

    @Override
    public String toString() {
        return descricao;
    }
}
