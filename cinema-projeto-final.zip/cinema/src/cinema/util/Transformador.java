package cinema.util;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Transformador {

    private Transformador() {
    }

    public static <T, R> List<R> transformar(List<T> origem, Function<T, R> funcao) {
        return origem.stream()
                .map(funcao)
                .collect(Collectors.toList());
    }
}
