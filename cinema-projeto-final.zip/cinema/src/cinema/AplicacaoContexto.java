package cinema;

import cinema.model.Cliente;
import cinema.model.Filme;
import cinema.model.Funcionario;
import cinema.model.Ingresso;
import cinema.model.Sala;
import cinema.model.Sessao;
import cinema.repository.Repositorio;
import cinema.repository.RepositorioEmMemoria;
import cinema.service.ConsultaIngressoService;
import cinema.service.ConsultaSessaoService;
import cinema.service.VendaService;

public class AplicacaoContexto {

    private final Repositorio<Filme, Integer> filmeRepositorio = new RepositorioEmMemoria<>(Filme::getId);
    private final Repositorio<Sala, Integer> salaRepositorio = new RepositorioEmMemoria<>(Sala::getId);
    private final Repositorio<Sessao, Integer> sessaoRepositorio = new RepositorioEmMemoria<>(Sessao::getId);
    private final Repositorio<Cliente, String> clienteRepositorio = new RepositorioEmMemoria<>(Cliente::getCpf);
    private final Repositorio<Funcionario, String> funcionarioRepositorio = new RepositorioEmMemoria<>(Funcionario::getCpf);
    private final Repositorio<Ingresso, Integer> ingressoRepositorio = new RepositorioEmMemoria<>(Ingresso::getId);

    private final VendaService vendaService = new VendaService(ingressoRepositorio);
    private final ConsultaSessaoService consultaSessaoService = new ConsultaSessaoService(sessaoRepositorio);
    private final ConsultaIngressoService consultaIngressoService = new ConsultaIngressoService(ingressoRepositorio);

    public Repositorio<Filme, Integer> getFilmeRepositorio() {
        return filmeRepositorio;
    }

    public Repositorio<Sala, Integer> getSalaRepositorio() {
        return salaRepositorio;
    }

    public Repositorio<Sessao, Integer> getSessaoRepositorio() {
        return sessaoRepositorio;
    }

    public Repositorio<Cliente, String> getClienteRepositorio() {
        return clienteRepositorio;
    }

    public Repositorio<Funcionario, String> getFuncionarioRepositorio() {
        return funcionarioRepositorio;
    }

    public Repositorio<Ingresso, Integer> getIngressoRepositorio() {
        return ingressoRepositorio;
    }

    public VendaService getVendaService() {
        return vendaService;
    }

    public ConsultaSessaoService getConsultaSessaoService() {
        return consultaSessaoService;
    }

    public ConsultaIngressoService getConsultaIngressoService() {
        return consultaIngressoService;
    }
}
