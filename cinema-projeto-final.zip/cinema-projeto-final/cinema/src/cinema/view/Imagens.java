package cinema.view;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;

public final class Imagens {

    private static final String pasta = "imagens";

    private Imagens() {
    }

    public static BufferedImage carregar(String nomeArquivo) {
        try {
            URL url = Imagens.class.getResource("/" + pasta + "/" + nomeArquivo);
            if (url != null) {
                return ImageIO.read(url);
            }
            String[] locais = {pasta, "src/" + pasta, "cinema/src/" + pasta};
            for (String local : locais) {
                File arquivo = new File(local, nomeArquivo);
                if (arquivo.isFile()) {
                    return ImageIO.read(arquivo);
                }
            }
        } catch (IOException ex) {
        }
        return null;
    }
}
